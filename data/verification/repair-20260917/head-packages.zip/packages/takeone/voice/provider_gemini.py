"""Ephemeral Gemini Live tokens. This process never proxies audio — the browser
holds the WebSocket, and the API key never leaves this process.

A minted token is single-use (`uses: 1`), must start its session within
`new_session_ttl_seconds`, and locks the model, the persona (system
instruction), the tool declarations and context-window compression so the
browser cannot alter any of them. Configuration changes therefore happen only
here, server-side.

The exact REST body in `_token_request_body` is the one surface that has never
run against the live API (this machine has no egress). It follows the
documented v1beta auth_tokens shape. This module is the only owner of the
provisioning wire format; tests pin the exact endpoint and locked fields.
"""

import http.client
import json
import math
import os
import socket
from datetime import datetime, timedelta, timezone

GEMINI_HOST = "generativelanguage.googleapis.com"
TOKEN_PATH = "/v1beta/auth_tokens"
API_KEY_ENVIRONMENT = "GEMINI_API_KEY"
MAX_RESPONSE_BYTES = 64 * 1_024
SUPPORTED_MODEL = "gemini-3.8-live"


class GeminiTokenError(RuntimeError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def _rfc3339(moment):
    return moment.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def validate_config(config):
    required = {
        "schema_version",
        "enabled",
        "model",
        "response_modalities",
        "compression_trigger_tokens",
        "token_ttl_seconds",
        "new_session_ttl_seconds",
        "vad_prefix_padding_ms",
        "vad_silence_duration_ms",
        "client_vad_end_silence_ms",
        "semantic_video_min_interval_ms",
    }
    if not isinstance(config, dict) or set(config) != required:
        raise ValueError("Invalid voice-live configuration fields")
    if type(config["schema_version"]) is not int or config["schema_version"] != 1:
        raise ValueError("Unsupported voice-live configuration schema")
    if type(config["enabled"]) is not bool:
        raise ValueError("voice-live enabled must be true or false")
    model = config["model"]
    if model != SUPPORTED_MODEL:
        raise ValueError(f"voice-live model must be {SUPPORTED_MODEL}")
    modalities = config["response_modalities"]
    if (
        not isinstance(modalities, list)
        or not modalities
        or any(m not in ("AUDIO", "TEXT") for m in modalities)
    ):
        raise ValueError("response_modalities must list AUDIO and/or TEXT")
    for name, low, high in (
        ("compression_trigger_tokens", 1_000, 1_000_000),
        ("token_ttl_seconds", 60, 1_800),
        ("new_session_ttl_seconds", 10, 300),
        ("vad_prefix_padding_ms", 0, 1_000),
        ("vad_silence_duration_ms", 100, 2_000),
        ("client_vad_end_silence_ms", 300, 2_000),
        ("semantic_video_min_interval_ms", 1_000, 60_000),
    ):
        value = config[name]
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(value)
            or not low <= value <= high
        ):
            raise ValueError(f"{name} must be between {low} and {high}")
    return config


class GeminiLiveProvider:
    """Mints ephemeral tokens with the session configuration locked server-side."""

    def __init__(
        self,
        config,
        api_key=None,
        *,
        connection_factory=http.client.HTTPSConnection,
        now=lambda: datetime.now(timezone.utc),
    ):
        self.config = validate_config(config)
        self._api_key = api_key if api_key is not None else os.environ.get(API_KEY_ENVIRONMENT)
        self._connect = connection_factory
        self._now = now

    def status(self):
        return {
            "transport": "gemini_live_browser_direct",
            "enabled": self.config["enabled"],
            "model": self.config["model"],
            "key_present": bool(self._api_key),
            "available": self.config["enabled"] and bool(self._api_key),
            "client_vad_end_silence_ms": self.config["client_vad_end_silence_ms"],
            "semantic_video_min_interval_ms": self.config["semantic_video_min_interval_ms"],
        }

    def _token_request_body(self, *, system_instruction, tools, resumption_handle):
        """Build the constrained v1beta Live configuration locked into the token."""
        connect = {
            "model": f"models/{self.config['model']}",
            "config": {
                "responseModalities": self.config["response_modalities"],
                "systemInstruction": {"parts": [{"text": system_instruction}]},
                "contextWindowCompression": {
                    "slidingWindow": {},
                    "triggerTokens": int(self.config["compression_trigger_tokens"]),
                },
                "sessionResumption": ({"handle": resumption_handle} if resumption_handle else {}),
                "realtimeInputConfig": {
                    "automaticActivityDetection": {
                        "disabled": False,
                        "startOfSpeechSensitivity": "START_SENSITIVITY_HIGH",
                        "endOfSpeechSensitivity": "END_SENSITIVITY_HIGH",
                        "prefixPaddingMs": int(self.config["vad_prefix_padding_ms"]),
                        "silenceDurationMs": int(self.config["vad_silence_duration_ms"]),
                    }
                },
            },
        }
        if tools:
            connect["config"]["tools"] = [{"functionDeclarations": tools}]
        moment = self._now()
        return {
            "uses": 1,
            "expireTime": _rfc3339(moment + timedelta(seconds=self.config["token_ttl_seconds"])),
            "newSessionExpireTime": _rfc3339(
                moment + timedelta(seconds=self.config["new_session_ttl_seconds"])
            ),
            "liveConnectConstraints": connect,
        }

    def mint(self, *, system_instruction, tools=(), resumption_handle=None):
        """One single-use token. Raises GeminiTokenError; never returns a fake token."""
        if not self.config["enabled"]:
            raise GeminiTokenError("live_disabled", "Voice live transport is disabled in configuration.")
        if not self._api_key:
            raise GeminiTokenError("key_missing", f"Set {API_KEY_ENVIRONMENT} in the server environment.")
        body = self._token_request_body(
            system_instruction=system_instruction,
            tools=list(tools),
            resumption_handle=resumption_handle,
        )
        connection = self._connect(GEMINI_HOST, timeout=10)
        try:
            connection.request(
                "POST",
                TOKEN_PATH,
                body=json.dumps(body),
                headers={"Content-Type": "application/json", "x-goog-api-key": self._api_key},
            )
            response = connection.getresponse()
            payload = response.read(MAX_RESPONSE_BYTES + 1)
        except (OSError, socket.timeout, http.client.HTTPException) as error:
            raise GeminiTokenError("mint_unreachable", f"Token service unreachable: {error}") from error
        finally:
            connection.close()
        if len(payload) > MAX_RESPONSE_BYTES:
            raise GeminiTokenError("mint_failed", "Token response exceeded the bounded size.")
        if response.status != 200:
            # Bodies may carry quota or key details; report status only, never echo secrets.
            raise GeminiTokenError("mint_failed", f"Token service answered HTTP {response.status}.")
        try:
            token = json.loads(payload)["name"]
        except (ValueError, KeyError, TypeError) as error:
            raise GeminiTokenError("mint_failed", "Token response had no token name.") from error
        if not isinstance(token, str) or not token:
            raise GeminiTokenError("mint_failed", "Token response had no token name.")
        return {
            "token": token,
            "model": self.config["model"],
            "expire_time": body["expireTime"],
            "new_session_expire_time": body["newSessionExpireTime"],
            "single_use": True,
            "client_vad_end_silence_ms": self.config["client_vad_end_silence_ms"],
            "semantic_video_min_interval_ms": self.config["semantic_video_min_interval_ms"],
        }
