"""The two-method recorder `BehaviorManager` expects, over `RecordingService`.

`BehaviorManager` calls exactly `start(plan_id, goal, behavior_id) -> take_id`
and `stop(take_id, reason)`. `RecordingService.start` wants a request identity,
a context and a source. Bridging those two is this file's whole job.

Request identities are derived, not generated: a duplicated settle event has to
replay idempotently through `recording_operations` instead of opening a second
take. The codebase already uses `uuid5` over a namespace for Director operation
identities, and this follows that pattern.
"""

from uuid import NAMESPACE_URL, uuid5

from takeone.recording.contracts import RecordingError

RECORDER_OPERATIONS = uuid5(NAMESPACE_URL, "https://takeone.local/recording/behavior-operations")


def start_request_id(behavior_id, plan_id):
    return str(uuid5(RECORDER_OPERATIONS, f"{behavior_id}:{plan_id}"))


def stop_request_id(take_id, reason):
    return str(uuid5(RECORDER_OPERATIONS, f"stop:{take_id}:{reason}"))


class BehaviorRecordingAdapter:
    def __init__(self, service, *, source="phone", aim_reference="witness_camera", motion_source=None):
        self.service = service
        self.source = source
        # Aim is computed on the witness camera, not on the phone's own frame,
        # so every take records which camera decided it was settled.
        self.aim_reference = aim_reference
        self.motion_source = motion_source

    def context(self, plan_id, goal, behavior_id):
        wire = goal.wire()
        return {
            "source": "embodied_behavior",
            "behavior_id": behavior_id,
            "plan_id": plan_id,
            "subject_track_ids": list(wire["subject_track_ids"]),
            "screen_target_uv": list(wire["screen_target_uv"]),
            "desired_subject_size_range": list(wire["desired_subject_size_range"]),
            "camera_relation": wire["camera_relation"],
            "recording_policy": wire["recording_policy"],
            "motion_source": self.motion_source,
            "aim_reference": self.aim_reference,
            "witness_to_lens_offset": "unmeasured",
            "identity_scope": "transient_visual_tracks_not_person_identity",
        }

    def start(self, plan_id, goal, behavior_id):
        request_id = start_request_id(behavior_id, plan_id)
        try:
            snapshot = self.service.start(
                request_id,
                self.context(plan_id, goal, behavior_id),
                None,
                source=self.source,
                plan_id=plan_id if isinstance(plan_id, str) and len(plan_id) == 64 else None,
            )
        except RecordingError:
            # BehaviorManager maps a missing take identity to recording_rejected.
            return None
        return snapshot.get("take_id") if isinstance(snapshot, dict) else None

    def stop(self, take_id, reason):
        try:
            # The reason travels into the event detail, so `target_lost:person-0004`
            # survives into the evidence trail rather than being flattened.
            self.service.stop(take_id, stop_request_id(take_id, reason))
        except RecordingError:
            return None
        return take_id
