# TAKE ONE — coordinated cart, five-joint arms, and camera feedback

**Decision document · 11 September 2026 · incorporates the five-motor modification and two-wheel-drive clarification.**

- **Final choice**
  - One compiled choreography, one progress variable, and one local execution authority for the cart and both arms.
  - A vehicle path tracker supplies feasible base motion; a constrained two-arm controller compensates that motion and corrects framing from the real camera.
  - Use the published SO-101 rigid-body transforms, MuJoCo, NumPy/SciPy, OSQP, and local Ruckig. Keep the AI director above this control layer.
  - Use calibrated cameras and explicit state estimation to connect the model to the physical world. Generated video never supplies measured geometry or motor commands.
- **What is established here**
  - The accompanying executable simulations use the upstream SO-101 joint transforms and meshes, with **five actuators per arm**. The gripper joint, its actuator, motor geometry, and downstream jaw assembly are removed.
  - Cart dimensions, steering, phone-holder geometry, payload masses, actuator response, and continuous torque limits are **declared assumptions**, not measurements of your equipment.
  - The numerical checks include actual MuJoCo execution and rendering. Their coverage and a retained payload-capacity failure appear in §12.
  - No physical robot, live iPhone, real person detector, or Seedance account was exercised. These are explicit acceptance steps, not simulated successes.

## 1. Architecture tree and execution contract

```mermaid
flowchart TD
    A["TAKE ONE"] --> B["Creative planning"]
    A --> C["Observed world"]
    A --> D["Physical execution"]
    A --> E["Capture and review"]
    B --> B1["Director and ShotSpec"]
    B --> B2["Validated rehearsal and Seedance"]
    C --> C1["Phone and overview cameras"]
    C --> C2["State estimates and uncertainty"]
    D --> D1["Shared path and progress"]
    D --> D2["Vehicle tracker and arm QP"]
    D --> D3["Limits, clearance, and stopping"]
    E --> E1["Real footage and findings"]
    E --> E2["FFmpeg and optional finishing"]
```

- **Planning authority**
  - The director proposes actor actions, viewing angles, framing, light placement, cart travel, and timing.
  - The compiler accepts or rejects physical requirements using the measured rig configuration.
  - A revised physical shot becomes a new preview; a failed exact position is not silently accepted as an approximate one.
- **Execution authority**
  - A single local process owns both arm buses and the vehicle command interface.
  - Every device references the same shot identifier, plan revision, progress, and local monotonic clock.
  - Independent scripts such as “cart runs for five seconds” and “arm starts after one second” are prohibited.
  - One stalled subsystem slows or stops the coordinated movement. The other devices do not continue blindly.
- **AI scope**
  - A tool-calling LLM handles the script, shot specification, revisions, actor instructions, and post-take interpretation.
  - Local vision and deterministic geometry/control handle observations and motion during recording.
  - This architecture does not require training a physics foundation model, VLA, or reinforcement-learning policy.

## 2. Actual hardware tree — five joints and an unresolved steering distinction

- **Arm A: camera**
  - Motor 1: `shoulder_pan`.
  - Motor 2: `shoulder_lift`.
  - Motor 3: `elbow_flex`.
  - Motor 4: `wrist_flex`.
  - Motor 5: `wrist_roll`.
  - Fixed attachment: phone holder, phone, and calibrated optical frame.
  - **Motor 6 and moving gripper are absent.** They are absent from actuator arrays, calibration, observations, commands, mass model, and collision geometry.
- **Arm B: lighting role carried forward from the project**
  - Same five-joint chain, with its actual rigid light/holder payload recorded separately.
  - If this arm also receives a phone holder, the attachment definition changes; its payload is never copied from Arm A by assumption.
- **Critical model detail**
  - The upstream body named `gripper` is the child of `wrist_roll`. Deleting that body would remove the fifth joint.
  - Keep that body's joint/frame and rename it `tool_carrier`. Replace its aggregate inertia, gripper meshes, gripper site, and moving-jaw child with the real rigid payload.
  - The wrist-roll motor itself remains upstream in the wrist assembly. The removed motor is the gripper actuator.
  - Do not retain the upstream gripper aggregate mass and then add the phone: that would count removed hardware.
- **Cart**
  - User information: likely **two driven wheels**.
  - Still unknown: steering mechanism, number of ground contacts, wheel radius, track, wheelbase, feedback sensors, and support geometry.
  - Two driven wheels do not identify the steering model:
    - **RC/Ackermann:** powered rear axle and steerable front wheels; use speed plus steering angle.
    - **Differential drive:** separately controlled left/right drive wheels; use two wheel rates.
  - The implementation activates exactly one verified drive adapter. The other model remains a reference test, not an automatic runtime fallback.
  - If there are literally only two ground contacts, a support polygon with area does not exist. Casters/additional supports or an entirely different active-balancing design would be required. The simulation assumes four supporting contacts and two driven wheels.

The manufacturer-aligned documentation identifies the five arm axes and the separate gripper axis. The exact five-joint transforms are taken from the pinned RobotStudio files, not the approximate link lengths in the previous HTML rehearsal. [SO-101 documentation](https://huggingface.co/docs/lerobot/en/so101), [pinned RobotStudio URDF](https://github.com/TheRobotStudio/SO-ARM100/blob/eecbe3e0a9ebb23e25ad7b2759b03884c6660903/Simulation/SO101/so101_new_calib.urdf).

## 3. Open-source selection — the smallest stack that satisfies this rig

| Component | Decision | Reason and boundary |
|---|---|---|
| MuJoCo | Use | Actual SO-101 model, FK, Jacobians, collision distances, inverse dynamics, arm dynamics and rendering. |
| NumPy + SciPy | Use | Transform calculations, numerical optimization, interpolation, state filtering, independent mathematical checks. |
| OSQP | Use | Small convex local QPs with explicit bounds and constraints; the tested controller directly assembles its task rows. |
| Ruckig Community | Use locally | Jerk-limited state-to-state motion, progress/speed control and stopping. No intermediate-waypoint cloud API in control. |
| Mink | Evaluated; not an additional dependency | Good MuJoCo task/limit abstraction. Our two image rows and prescribed-base constraints are small enough to implement directly with OSQP. Avoid two production IK stacks. |
| CasADi + IPOPT | Later if needed | Useful for jointly optimizing complex base/arm trajectories over a horizon; unnecessary for the initial clear-stage line/arc choreography. |
| MoveIt 2 + Nav2 Smac | Later navigation product | Useful with a ROS deployment and general navigation. Combining packages does not automatically coordinate cinematography or make a steering cart holonomic. |
| XLeRobot | Reference | Relevant dual-SO-101 mechanical/simulation work. Its base configuration is not evidence for your RC cart's steering equations. |
| OpenCV | Use | Intrinsics/extrinsics, ArUco board tracking, PnP, triangulation, geometry validation. |
| Apple Vision + MediaPipe | Use | Phone face/landmark tracking and overview body/foot observations. Their outputs need identity, confidence, timestamp and frame conversion. |
| React + TypeScript + Three.js | Use | Rehearsal and live display, with backend poses as authority. |
| Python + Pydantic + FastAPI | Use | Typed contracts, director tools, coordinator and UI connections. |
| Swift + AVFoundation | Use | Capture, local recording, camera settings and timestamped observations. |
| SQLite + files + FFmpeg | Use | Session metadata, immutable takes, local telemetry and conventional assembly. |

- **Why a coordinated tracker is the selected method**
  - This is a known room with short scripted shots, not arbitrary mobile manipulation among unknown obstacles.
  - Compute a feasible vehicle route first, solve both arms along it, then retime all components together.
  - During execution, track the route and use the actual base motion in the arm controller.
  - Stop and revise a route that exhausts arm reach. Do not ask a local IK solver to invent a global detour.
  - This choice is an engineering judgement based on the task and simulation results, not a universal ranking of robotics software.

The primary references establish the library capabilities: [MuJoCo computation](https://mujoco.readthedocs.io/en/stable/computation/index.html), [OSQP](https://osqp.org/docs/), [Mink](https://kevinzakka.github.io/mink/), [Ruckig](https://github.com/pantor/ruckig), [CasADi](https://web.casadi.org/docs/), [Nav2 Smac](https://github.com/ros-navigation/navigation2/tree/main/nav2_smac_planner), and [XLeRobot](https://github.com/Vector-Wangel/XLeRobot). Their documentation is not evidence that this particular rig is calibrated or safe.

## 4. Coordinate frames and the exact five-joint forward model

```mermaid
flowchart TD
    W["World: floor markers"] --> B["Cart reference frame"]
    W --> O["Fixed overview camera"]
    B --> A["Camera-arm base"]
    B --> L["Light-arm base"]
    A --> F["Five joints and wrist frame"]
    L --> G["Five joints and wrist frame"]
    F --> C["Rigid holder and optical frame"]
    G --> H["Rigid light and emitter frame"]
```

### 4.1 Conventions

- World/cart: right-handed, `x` forward, `y` left, `z` up.
- Optical camera frame: `x` image-right, `y` image-down, `z` forward.
- SI units internally: metres, seconds, radians, kilograms, newtons, newton-metres.
- Transform notation: ${}^{A}T_B$ maps coordinates expressed in frame $B$ into frame $A$.
- MuJoCo quaternions are stored as `(w,x,y,z)`; SciPy Rotation's default quaternion interface uses `(x,y,z,w)`. Convert explicitly.
- Three.js uses a different default up convention. Set the scene convention once or use one fixed world-to-render transform. Never swap axes inside motion logic.

For a rigid transform:

$$
{}^{A}T_B=\begin{bmatrix}{}^{A}R_B&{}^{A}p_B\\0&1\end{bmatrix},\quad
{}^{A}p={}^AT_B\,{}^Bp,\quad
T^{-1}=\begin{bmatrix}R^T&-R^Tp\\0&1\end{bmatrix}.
\tag{1}
$$

Homogeneous point notation is implied in the middle expression. Composition order is not interchangeable.

### 4.2 Published arm origins

The following values are a readable extract from the **new-calibration** URDF. Runtime loads the pinned source at full stored precision; this table is not an alternative hand-coded robot model. Every joint axis is `(0,0,1)` **in its own joint frame**; this does not mean all motors rotate about world vertical.

| Joint | Parent-to-joint translation (m) | Origin RPY (rad) | Published range (rad) |
|---|---|---|---|
| `shoulder_pan` | `(0.0388353, 0, 0.0624)` | `(3.14159, 0, -3.14159)` | `-1.91986` to `1.91986` |
| `shoulder_lift` | `(-0.0303992, -0.0182778, -0.0542)` | `(-1.5708, -1.5708, 0)` | `-1.74533` to `1.74533` |
| `elbow_flex` | `(-0.11257, -0.028, 0)` | `(0, 0, 1.5708)` | `-1.69` to `1.69` |
| `wrist_flex` | `(-0.1349, 0.0052, 0)` | `(0, 0, -1.5708)` | `-1.65806` to `1.65806` |
| `wrist_roll` | `(0, -0.0611, 0.0181)` | `(1.5708, 0.0486795, 3.14159)` | `-2.74385` to `2.84121` |

URDF defines the origin rotation as:

$$
R_{\mathrm{origin},i}=R_z(y_i)R_y(p_i)R_x(r_i),\qquad
T_i(q_i)=T_{\mathrm{origin},i}\begin{bmatrix}\operatorname{Rot}(a_i,q_i)&0\\0&1\end{bmatrix}.
\tag{2}
$$

Here $(r_i,p_i,y_i)$ are URDF roll, pitch and yaw; $a_i$ is the local joint axis. For a unit axis $a$:

$$
\operatorname{Rot}(a,q)=I+\sin(q)[a]_\times+(1-\cos q)[a]_\times^2.
\tag{3}
$$

The camera transform is:

$$
{}^WT_C(t)={}^WT_B(t)\;{}^BT_{A_c}\left(\prod_{i=1}^{5}T_i(q_{c,i}(t))\right){}^{F_c}T_C.
\tag{4}
$$

The light uses the same expression with its own mount, five joints, and emitter transform. A cart translation or rotation therefore changes **both** end-effectors even when every arm joint is stationary.

### 4.3 Camera mount and servo calibration

- The rigid transform ${}^{F_c}T_C$ contains the optical centre offset, not just the holder centre.
- The physical holder orientation is unknown. The simulation assumes optical forward along negative local wrist-roll `z`, and records that assumption.
- A different mount orientation changes camera pointing, roll coupling, and the reachable viewing directions. Recalibrate and recompile after any mount change.
- Represent encoder conversion explicitly:

$$
q_i=\sigma_i\,k_i\,(e_i-e_{0,i})+q_{0,i},\qquad \sigma_i\in\{-1,+1\}.
\tag{5}
$$

- $e_i$ is encoder reading, $e_{0,i}$ its calibrated zero, $k_i$ radians per count, and $q_{0,i}$ the model-zero offset. Do not substitute a normalized LeRobot action value for radians.
- Upstream joint limits are model limits. Hardware soft limits must be the more restrictive measured limits with stopping allowance.
- Upstream URDF effort/velocity fields and simulation force ranges are not measurements of continuous capability at your voltage.
- Use a five-motor robot adapter/configuration. A stock six-motor enumeration must not attempt to read or command absent motor 6.

### 4.4 Accuracy means error budgets, not extra decimals

For small independent calibration errors, an approximate camera-position covariance is:

$$
\Sigma_{p_C}\approx J_q\Sigma_qJ_q^T+J_B\Sigma_BJ_B^T+J_m\Sigma_mJ_m^T+\Sigma_{\mathrm{flex}}.
\tag{6}
$$

All terms must be expressed in compatible coordinates. Joint backlash, base localization, mount offset and structural flex remain even if the numerical IK residual is tiny. Use measured holdout camera poses to verify the combined error. An internal FK agreement of micrometres is **not** micrometre physical accuracy.

## 5. Cart mathematics — two possible two-wheel-drive layouts

### 5.1 Shared planar constraint

Let the vehicle reference point be $(x_B,y_B)$, heading $\theta$, forward speed $v$, and yaw rate $\omega$:

$$
\dot x_B=v\cos\theta,\quad \dot y_B=v\sin\theta,\quad \dot\theta=\omega,\quad
-\sin\theta\,\dot x_B+\cos\theta\,\dot y_B=0.
\tag{7}
$$

The final expression prohibits instantaneous sideways translation. This applies to both layouts. Wheels following a curved path can produce a lateral displacement over time, but that is a different trajectory.

### 5.2 Ordinary RC steering / Ackermann

Use the rear-axle midpoint as the bicycle-model reference, wheelbase $L$, and equivalent steering angle $\delta$:

$$
\omega=\frac{v}{L}\tan\delta,\quad \kappa=\frac{\tan\delta}{L},\quad
R_{\min}=\frac{L}{\tan\delta_{\max}}.
\tag{8}
$$

- Inputs: requested forward speed and steering-servo position/rate.
- Steering is a state with a measured rate limit: $|\dot\delta|\le\dot\delta_{\max}$.
- At zero forward speed, this ideal model cannot rotate the cart in place.
- For turning radius $R$ and front track $b_f$, geometric steering angles are:

$$
\tan\delta_{\rm inner}=\frac{L}{R-b_f/2},\qquad
\tan\delta_{\rm outer}=\frac{L}{R+b_f/2}.
\tag{9}
$$

The actual linkage is calibrated against steering commands; equation (9) is not a command to independently steer wheels that share one linkage. Tire slip and suspension motion are outside this low-speed kinematic model.

### 5.3 Independently driven left/right wheels

With wheel radius $r$, drive-wheel track $b$, and wheel rates $\dot\phi_L,\dot\phi_R$:

$$
v=\frac r2(\dot\phi_R+\dot\phi_L),\quad
\omega=\frac r b(\dot\phi_R-\dot\phi_L),
\tag{10}
$$

$$
\dot\phi_L=\frac{v-\omega b/2}{r},\qquad
\dot\phi_R=\frac{v+\omega b/2}{r}.
\tag{11}
$$

Opposite wheel rates permit a stationary-centre turn if the support/caster geometry and friction permit it. A two-wheel-drive RC axle with one motor is **not** this mechanism.

### 5.4 Path construction and steering feasibility

For a forward path $p_B(s)=(x(s),y(s))$:

$$
\theta(s)=\operatorname{atan2}(y'(s),x'(s)),\quad
\ell'(s)=\sqrt{x'(s)^2+y'(s)^2},\quad
\kappa(s)=\frac{x'y''-y'x''}{(x'^2+y'^2)^{3/2}}.
\tag{12}
$$

$$
v=\ell'(s)\dot s,\quad\omega=\kappa v,\quad
\delta=\arctan(L\kappa),\quad
\dot\delta=\frac{L\kappa'(s)\dot s}{1+(L\kappa)^2}.
\tag{13}
$$

- Use lines and smooth arcs with planned transitions for the initial stage.
- A line-to-arc join cannot jump steering angle while moving. Use a curvature-continuous transition, or stop and steer before the next segment.
- Reject excessive curvature, steering rate, or insufficient room for the full cart footprint and the arms' swept volume.
- Reverse movement and differential-drive spins require explicitly typed segments; equations (12–13) assume a regular forward path.
- For a local lookahead tracker, a target at vehicle-relative $(x_L,y_L)$ gives $\kappa_{\rm pp}=2y_L/(x_L^2+y_L^2)$. Apply steering and curvature limits and verify the resulting path. The supplied arc simulation uses its known curvature, not a tested arbitrary-path pure-pursuit implementation.

The base-and-arm Jacobian composition follows the standard mobile-manipulation formulation; its application to this modified SO-101 rig is our design. [Modern Robotics: mobile manipulation](https://modernrobotics.northwestern.edu/nu-gm-book-resource/13-5-mobile-manipulation/).

## 6. How camera observations become a current world state

```mermaid
flowchart TD
    A["Timestamped camera observations"] --> B["Phone landmarks and framing"]
    A --> C["Overview markers and actor"]
    B --> D["Identity and observation checks"]
    C --> D
    D --> E{"Metric estimate supported?"}
    E -->|"Yes"| F["Fuse position and velocity"]
    E -->|"No"| G["Mark unknown and restrict motion"]
    F --> H["WorldState with uncertainty"]
    G --> H
```

### 6.1 Measurements and geometry

For world point $p_W$, camera centre $c_W$, and camera-to-world rotation $R_{WC}$:

$$
p_C=R_{WC}^T(p_W-c_W)=(X,Y,Z)^T,\quad
u=f_xX/Z+c_x,\quad v_p=f_yY/Z+c_y,\quad Z>0.
\tag{14}
$$

$v_p$ denotes image vertical coordinate, distinct from cart speed $v$. Undistort pixel measurements using the calibrated lens model before using these equations. Resolution, cropping, lens switches and stabilization can change the effective intrinsics.

- **Phone:** selected face/landmarks, normalized framing, confidence, exposure timestamp, camera settings.
- **Overview:** cart marker board, actor body/feet, marker-based room geometry, occlusion and identity state.
- **Joint bus:** measured positions, sample time, error/status and available current/temperature telemetry.
- **Vehicle:** steering state and wheel/drive feedback where available. ESC ERPM is not measured world distance.

OpenCV provides the calibration/projection/triangulation operations; PnP estimates a camera/object pose from known 3D geometry and corresponding pixels. [OpenCV camera geometry](https://docs.opencv.org/4.x/d9/d0c/group__calib3d.html), [PnP](https://docs.opencv.org/4.x/d5/d1f/calib3d_solvePnP.html).

### 6.2 Obtain metric coordinates with existing cameras

- **Cart pose:** a rigid board with known marker dimensions and offsets; combine its observed pose with the overview camera's calibrated world pose.
- **Actor floor position:** intersect an undistorted foot ray with the floor. Feet must be visible and actually near the floor.
- **Face position:** do not apply floor homography to a face. For an initial known posture, a measured height is a prior, with uncertainty.
- **Moving-face metric mode:** use corresponding landmarks from the phone and overview when both views, calibration and timing support triangulation.
- A model's “3D body landmarks” are not automatically registered to the room or robot. Registration, scale checks and uncertainty remain necessary.

For a calibrated camera ray $p(\lambda)=c+\lambda r$ intersecting plane $n^Tp+d=0$:

$$
\lambda=-\frac{n^Tc+d}{n^Tr};\qquad p=c+\lambda r.
\tag{15}
$$

Reject near-parallel rays or intersections behind the camera. For a floor estimate, this equation applies to the visible floor-contact feature, not every body keypoint.

With two calibrated camera projection matrices $P_1,P_2$, homogeneous point $\bar p$, and undistorted pixels $(u_i,v_i)$:

$$
A\bar p=0,\qquad
A=\begin{bmatrix}
u_1P_{1,3}-P_{1,1}\\v_1P_{1,3}-P_{1,2}\\
u_2P_{2,3}-P_{2,1}\\v_2P_{2,3}-P_{2,2}
\end{bmatrix}.
\tag{16}
$$

Solve by SVD, divide by the homogeneous component, then refine reprojection error. Reject wrong identity, negative depth, poor parallax, high reprojection residual or excessive time skew. The two cameras must refer to the **same physical feature at the same time**, not arbitrary face-box centres.

For rectified stereo, the useful sensitivity approximation is:

$$
Z=\frac{fB}{d},\qquad \sigma_Z\approx\frac{Z^2}{fB}\sigma_d.
\tag{17}
$$

This explains why a small baseline or distant actor degrades depth accuracy. For the moving, non-rectified pair use its actual calibrated geometry. Extrinsic and timing errors must be added to the pixel-noise uncertainty.

### 6.3 Filter and timing

Use a modest state such as cart pose/velocity and actor position/velocity. Predict with the vehicle model and a short constant-velocity actor model. Fuse measurements with their covariance:

$$
\hat x^-_k=f(\hat x_{k-1},u_{k-1}),\quad
P^-_k=F_kP_{k-1}F_k^T+Q_k,
\tag{18}
$$

$$
K_k=P^-_kH_k^T(H_kP^-_kH_k^T+R_k)^{-1},\quad
\hat x_k=\hat x^-_k+K_k(z_k-h(\hat x^-_k)).
\tag{19}
$$

Use a linear solve, wrapped angle innovations, and the Joseph covariance update:

$$
P_k=(I-KH)P^-(I-KH)^T+KRK^T.
\tag{20}
$$

- Estimate clock mapping $t_{\rm local}=a\,t_{\rm phone}+b$ and its uncertainty.
- Interpolate encoder/base poses to camera exposure time; do not combine arbitrary latest samples from different instants.
- Translational time-skew error is approximately $\|v_{\rm relative}\|\Delta t$. At `0.3 m/s`, `80 ms` can mean `24 mm`, before calibration error.
- Use latest-value observation buffers. An old observation queue is not a current world model.
- Reprojection residual, measurement age, covariance and identity confidence can all disable metric movement.

### 6.4 What “understanding the real world” means operationally

- **Observed:** actor at a mark, face shifted in frame, cart changed pose, person entered a reserved corridor, marker disappeared.
- **Estimated:** 3D face position, actor velocity, cart pose between marker observations, with confidence and time.
- **Predicted:** next short trajectory, stopping envelope, possible limit or collision.
- **Unknown:** occluded obstacles, unobserved geometry, uncertain person identity or unmeasured torque capability.
- A known-stage model plus live vision can support this project. It does not establish arbitrary-room perception.
- If you later require operation around unmodeled furniture, add a calibrated depth/occupancy sensing path. A generated world or a semantic LLM answer cannot declare unseen space clear.
- Vision detector deployment remains an explicit hardware test: [Apple face landmarks](https://developer.apple.com/documentation/vision/vndetectfacelandmarksrequest), [MediaPipe Pose Landmarker](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker/python).

## 7. Inverse kinematics and coordinated control

```mermaid
flowchart TD
    A["Shot targets and current state"] --> B["Vehicle path tracker"]
    A --> C["Camera and light objectives"]
    B --> D["Measured base twist"]
    C --> E["Constrained two-arm QP"]
    D --> E
    E --> F{"Motion and stopping checks pass?"}
    F -->|"Yes"| G["One device command batch"]
    F -->|"No"| H["Coordinated stop and revision"]
```

### 7.1 Position, aim and focus are separate requirements

- A face location is a look-at target. It is not the position the camera should occupy.
- Camera location requires three coordinates, a frame and tolerances; distance alone is insufficient.
- Camera orientation determines the view. A lower camera can tilt up, but that does not create an eye-level viewpoint.
- Optical focus is an AVFoundation camera-setting operation, not an IK operation.
- A five-joint arm cannot guarantee an arbitrary six-dimensional camera pose. Freeing roll alone does not guarantee every position-plus-aim combination either: the joint layout and mount matter.

For desired forward viewing direction $f=(p_{\rm actor}-p_C)/\|p_{\rm actor}-p_C\|$, a level camera basis is:

$$
r=\frac{f\times u_W}{\|f\times u_W\|},\quad d=f\times r,\quad R_{WC}^{*}=[r\ d\ f],\quad u_W=(0,0,1)^T.
\tag{21}
$$

When looking almost parallel to world-up, use the preceding valid orientation basis or reject the singular orientation construction. The IK still checks whether the rig can realize this basis.

### 7.2 Forward and differential kinematics

Let the full configuration be:

$$
q=(x_B,y_B,\theta,q_{c,1:5},q_{l,1:5})^T\in\mathbb R^{13}.
\tag{22}
$$

For a revolute joint with world axis $a_i$, origin $o_i$, and camera point $p_C$:

$$
J_{p,i}=a_i\times(p_C-o_i),\qquad J_{\omega,i}=a_i.
\tag{23}
$$

For a prismatic joint, the columns are $J_{p,i}=a_i$, $J_{\omega,i}=0$. MuJoCo supplies site Jacobians for the actual chain and offset camera site. The simulation independently checks them using central differences.

Use mobile control coordinates $\nu=(v,\omega,\dot q_c,\dot q_l)^T\in\mathbb R^{12}$:

$$
\dot q=S(\theta)\nu,\quad
S=\begin{bmatrix}
\cos\theta&0&0_{1\times10}\\
\sin\theta&0&0_{1\times10}\\
0&1&0_{1\times10}\\
0_{10\times1}&0_{10\times1}&I_{10}
\end{bmatrix},\quad J_{\rm mobile}=J_qS.
\tag{24}
$$

The matrix excludes an independently commanded sideways cart velocity. For Ackermann, also enforce $\omega-v\tan\delta/L=0$ using the actual steering state. In the selected tracker, the base values are prescribed by the feasible vehicle tracker, while the arm solve compensates them.

### 7.3 Planning IK

Use desired camera position error $e_p=p^*-p$ and world-frame orientation error:

$$
e_R=\operatorname{Log}(R^*R^T)^\vee.
\tag{25}
$$

At a fixed candidate base pose, solve bounded small updates of the ten arm joints, warm-started from the previous path sample:

$$
\min_{\Delta q_a}\ \frac12\|W(J_a\Delta q_a-e)\|^2+\frac{\lambda^2}{2}\|\Delta q_a\|^2,
\quad q_{\min}+m\le q_a+\Delta q_a\le q_{\max}-m.
\tag{26}
$$

- $q_a=(q_c,q_l)$ and $m$ is a soft-limit margin.
- Scale position and angular errors by declared tolerances so metres and radians are not mixed arbitrarily.
- Weights express preferences, not strict guarantees. Exact-position requirements must pass a final position-residual check.
- The gaze, camera path, light direction and horizon objectives may conflict. Return achieved residuals explicitly.
- Use bounded iterations and consistent branch seeding. Reject discontinuities, singular configurations without margin, collisions and excessive residual.
- A local solver does not prove global infeasibility. The director can offer another base setup or a simpler shot.

### 7.4 Live image feedback with correct dimensions

Use focal-normalized feature coordinates $\xi=(X/Z,Y/Z)^T$. These are distinct from both pixels and image-width-normalized coordinates.

$$
D\pi(p_C)=\begin{bmatrix}1/Z&0&-X/Z^2\\0&1/Z&-Y/Z^2\end{bmatrix}.
\tag{27}
$$

For world actor point $a$, world camera position $p$, camera rotation $R=R_{WC}$, and the world-frame site Jacobians:

$$
J_{\xi}=D\pi\left[-R^TJ_p+R^T[a-p]_\times J_\omega\right],\quad
\dot\xi=J_{\xi}S\nu+D\pi R^T\dot a.
\tag{28}
$$

The actor-velocity term matters when the person moves. Apply it only when the estimate is fresh enough; otherwise reduce reliance on feedforward and obey the uncertainty limit.

The desired feature dynamics are:

$$
J_{\xi}S\nu\approx \dot\xi^*-K_{\xi}(\xi_{\rm observed}-\xi^*)-D\pi R^T\hat{\dot a}.
\tag{29}
$$

This replaces the earlier shortcut that directly mapped three image errors to a six-dimensional camera twist. Such a mapping requires an interaction model; it is not dimensionally complete on its own.

- For push-ins, subject scale intentionally changes with progress. Do not counteract it with a constant-size tracker.
- The tested runtime uses the two image-centre features. Face scale is logged for review; arbitrary scale control is not claimed as tested.
- Preserve target identity. Loss of a selected face is not permission to follow the nearest new face.
- An intentional exit is a beat state that releases tracking. It is not ordinary detector failure.

### 7.5 The local QP

Stack camera path, image-framing, light pose, posture and smoothness tasks into $A\nu\approx b$:

$$
\min_\nu\ \frac12\|A\nu-b\|^2+\frac\epsilon2\|\nu\|^2,
\quad l\le C\nu\le u.
\tag{30}
$$

OSQP receives $P=A^TA+\epsilon I$, linear objective $c=-A^Tb$, and constraint matrix $C$. $P$ is positive definite for $\epsilon>0$.

- **Hard constraints**
  - Verified vehicle speed/yaw rate supplied by the path tracker.
  - Joint position, velocity and near-term stopping margins.
  - Linearized geometric clearance where valid.
  - Command acceleration limits.
- **Soft objectives**
  - Framing correction within the allowed path corridor.
  - Camera/light tracking and posture away from limits.
  - Small corrections to avoid visual jitter.
- **Solver handling**
  - Check status, finite values and actual constraint residuals.
  - Recheck the nonlinear result and the stopping envelope before sending commands.
  - A solver failure goes to the previously validated coordinated stopping procedure. Zeroing velocity instantaneously is not a valid physical stop.
  - Reuse the sparse structure and warm-start in production. The benchmark deliberately includes rebuilding OSQP each tick, so its timing is not the minimum possible solver time. [OSQP Python interface](https://osqp.org/docs/interfaces/python.html)

For arm joint commands at measured time step $\Delta t$:

$$
\frac{q_{\min}+m-q}{\Delta t}\le\dot q\le\frac{q_{\max}-m-q}{\Delta t},\quad
|\dot q|\le v_{\max},
\tag{31}
$$

$$
|\dot q_k-\dot q_{k-1}|\le a_{\max}\Delta t,\quad
|\dot q_k-2\dot q_{k-1}+\dot q_{k-2}|\le j_{\max}\Delta t^2.
\tag{32}
$$

**These one-step bounds are not sufficient to guarantee future stopping feasibility.** The initial experiment reached inconsistent speed/jerk bounds near zero speed. The corrected design gives vehicle speed/braking to local Ruckig and uses lookahead stopping/limit checks around the arm solve. It does not silently relax a safety limit to recover a QP solution.

## 8. Synchronization and smooth motion

```mermaid
flowchart TD
    A["Accepted choreography"] --> B["Base path"]
    A --> C["Camera-arm path"]
    A --> D["Light-arm path"]
    B --> E["Joint feasibility and timing limits"]
    C --> E
    D --> E
    E --> F["One progress governor"]
    F --> G["Synchronized references"]
    G --> H["Observed progress and tracking error"]
    H --> F
```

### 8.1 One shared path parameter

Store all nominal references as functions of progress $s\in[0,1]$:

$$
\Gamma(s)=\{T_B(s),q_c(s),q_l(s),\xi^*(s),\text{actor beats}(s)\}.
\tag{33}
$$

This is the object consumed by rehearsal, motion execution and the Seedance reference renderer. It is not three independently timed files.

For any joint curve $q(s)$:

$$
\dot q=q'\dot s,\qquad
\ddot q=q''\dot s^2+q'\ddot s,
\tag{34}
$$

$$
\dddot q=q'''\dot s^3+3q''\dot s\ddot s+q'\dddot s.
\tag{35}
$$

- A phase generator with bounded jerk does not automatically bound joint jerk: use the full expressions.
- The fastest allowed progress is limited by the slowest relevant arm joint, cart speed, steering rate, acceleration, clearance and stopping allowance.
- A useful velocity-only bound is $\dot s\le\min_i(v_{i,\max}/|q_i'|)$ for nonzero derivatives. Additional limits from (34–35) are still required.
- With uniform time stretching $t_{\rm new}=\alpha t_{\rm old}$, velocities, accelerations and jerk scale by $\alpha^{-1},\alpha^{-2},\alpha^{-3}$ respectively. Choose:

$$
\alpha\ge\max\left(1,\max_i\frac{|\dot q_i|}{v_i},\max_i\sqrt{\frac{|\ddot q_i|}{a_i}},\max_i\sqrt[3]{\frac{|\dddot q_i|}{j_i}}\right).
\tag{36}
$$

The right-hand side maxima range over the trajectory. Include vehicle and steering limits too. Recheck geometry after any geometric smoothing; merely slowing a colliding path cannot fix it.

### 8.2 Runtime progress

- The coordinator produces a desired progress rate from the shot and actor beat.
- A local governor slows it when observed cart progress, joint tracking, image confidence or remaining stopping space deteriorates.
- At a beat pause, all references decelerate together. A camera-specific expressive movement is a deliberately defined sub-motion, not accidental drift.
- Large actor displacement or a changed obstacle produces a coordinated stop and recompile from the measured state.
- A camera-path-critical shot restricts adaptation; a framing-critical shot permits correction inside its approved corridor.
- Stream nearby time-stamped references with sequence numbers. Measure bus skew and actual encoder motion rather than assuming simultaneous USB writes.

Ruckig's documented Community intermediate-waypoint mode uses a cloud API. Only its local state-to-state/progress/velocity operation is selected here. Arbitrary waypoint clouds are not sent into the live control loop. [Ruckig intermediate-waypoint documentation](https://github.com/pantor/ruckig#intermediate-waypoints)

### 8.3 CompiledShot contents

- `plan_id`, immutable revision, `drive_type`, joint names, model/calibration hashes.
- Nominal base path, both five-joint paths, time/progress derivatives and accepted residuals.
- Camera lens/intrinsics, rigid camera mount, lighting state and actor beats.
- Framing references, allowed correction corridor, velocity/acceleration/jerk constraints.
- Clearance report, payload/stability status, and a validated approach/stop procedure.
- Start conditions and requirements for current sensor freshness.

## 9. Real physics — load, stability, traction and stopping

```mermaid
flowchart TD
    A["Candidate coordinated motion"] --> B["Gravity and actuator load"]
    A --> C["All link and payload clearances"]
    A --> D["Support and acceleration"]
    B --> E{"Within measured capability?"}
    C --> E
    D --> E
    E -->|"Yes"| F["Predict stopping envelope"]
    E -->|"No"| G["Change pose, path, payload or setup"]
    F --> H["Slow physical rehearsal"]
```

### 9.1 Dynamics and payload

The rigid-body dynamics have the form:

$$
M(q)\ddot q+C(q,\dot q)\dot q+g(q)=B\tau+J_c(q)^Tf_c+\tau_{\rm external}.
\tag{37}
$$

- Use measured masses, centres of mass and inertias for the modified payload.
- Keep all five surviving joints and their link inertia. Remove motor 6 and removed gripper geometry/mass.
- Include cart acceleration when estimating demand on an arm mounted to it.
- MuJoCo inverse dynamics predicts torque demand for a specified trajectory/model. Actual servo friction, backlash, thermal behaviour and controller gains still need measurement.
- Treat a servo's stall torque separately from continuous permissible torque. The original XML's force limit is not a verified continuous rating for your servos.

The phone's gravitational contribution about a joint is related to its translational COM Jacobian:

$$
\tau_{\rm gravity,phone}=J_{p,\rm phone}^T\,m_p\,g_W,
\tag{38}
$$

with the opposite sign needed from the actuator to hold it. The scalar lever-arm estimate is $|\tau|\approx m_pg\ell_\perp$. Reducing the holder's lever arm can help more than changing the IK solver.

For a required margin fraction $\eta$:

$$
|\tau_i(t)|\le(1-\eta)\tau_{i,\rm continuous}(T,V),
\tag{39}
$$

where permissible torque can depend on temperature $T$ and supply voltage $V$. The current illustrative `300 g` camera payload fails this gate under the deliberately assumed `1.0 N·m` continuous cap; see §12. Slowing motion reduces inertial torque but does not remove static gravity load.

### 9.2 Cart stability with both arms

Compute the combined centre of mass from every cart, arm and payload body:

$$
c(q)=\frac{\sum_i m_i p_{\mathrm{COM},i}(q)}{\sum_i m_i}.
\tag{40}
$$

For a flat-floor, low-dynamics screen using base horizontal acceleration $a_{xy}$:

$$
p_{\rm eff}=c_{xy}-\frac{c_z}{g}a_{xy},\quad
A_{\rm support}p_{\rm eff}\le b_{\rm support}-m_{\rm support}.
\tag{41}
$$

The support polygon comes from actual contact points, not the cart deck outline. Both arms moving outward can move the COM even while the cart is stationary.

For more dynamic motion, total contact force $F=M_{\rm total}(\ddot c-g_W)$ and centroidal angular-momentum rate $\dot H_C$ give the flat-plane ZMP relation:

$$
p_{Z,x}=c_x-\frac{c_zF_x+\dot H_{C,y}}{F_z},\quad
p_{Z,y}=c_y-\frac{c_zF_y-\dot H_{C,x}}{F_z},\quad F_z>0.
\tag{42}
$$

This explains a limitation of the simple COM screen: arm angular momentum, vertical acceleration, wheel unloading and suspension roll are not covered by equation (41). The supplied tests execute the quasi-static screen; they do not claim to validate the full ZMP/contact model.

### 9.3 Friction and turning acceleration

$$
a_{\rm lateral}=v\omega=v^2\kappa,\qquad
\sqrt{a_{\rm longitudinal}^2+a_{\rm lateral}^2}\lesssim\mu g.
\tag{43}
$$

This is a conservative aggregate screening concept, not a tire model. A two-driven-wheel axle may have less usable traction than total vehicle weight suggests. Measure acceleration/braking on the intended floor and under the actual arm configurations.

### 9.4 Collision and stopping

For pairwise distance $d(q,t)$ and required clearance $d_{\rm safe}$, a local linearized constraint is:

$$
J_dS\nu\ge\frac{d_{\rm safe}-d(q,t)}{\Delta t}-\frac{\partial d}{\partial t}.
\tag{44}
$$

Recheck the nonlinear swept movement after solving. Linearization and sampled collision checks alone do not establish continuous safety. Include camera/holder/phone, cables, both arms, cart footprint, actor envelope and obstacles. Adjacent links require explicit collision-pair policy; avoid hiding genuine interference with broad exclusions.

An acceleration-only braking expression is a **lower bound** when jerk/actuator response also limits braking:

$$
d_{\rm lower}=v\tau_{\rm delay}+\frac{v^2}{2a_{\rm brake}}.
\tag{45}
$$

Use the actual jerk-limited stopping trajectory $v_{\rm braking}(t)$ in implementation:

$$
d_{\rm stop}=v\tau_{\rm delay}+\int_0^{T_{\rm stop}}v_{\rm braking}(t)\,dt.
\tag{46}
$$

The required clearance also includes actor approach, pose uncertainty and a physical buffer. In the executed test, `0.12 m/s`, `0.15 s` delay, `0.2 m/s²` braking and `0.5 m/s³` jerk require `0.078 m`, versus the acceleration-only `0.054 m`. Using the smaller value would understate stopping distance.

- Loss of perception, solver infeasibility, stale calibration or a new obstacle triggers the validated stop state.
- A gravity-loaded arm may need powered holding or mechanical support. Blindly removing torque can drop the phone.
- The physical emergency-stop arrangement must be tested with the actual rig and payload. Vision/LLM software is not the independent emergency-stop mechanism.

## 10. End-to-end steps, including Seedance and actor guidance

```mermaid
flowchart TD
    A["Brief and measured rig"] --> B["Typed shot and actor beats"]
    B --> C{"Compile and physical checks"}
    C -->|"Rejected"| D["Director revises shot"]
    D --> B
    C -->|"Accepted"| E["Shared rehearsal trajectory"]
    E --> F["Actor rehearsal"]
    E --> G["Clay reference for Seedance"]
    F --> H["Coordinated real take"]
    H --> I["Review and real-footage edit"]
```

- **Step 1 — establish the setup**
  - Verify drive type, five motor IDs per arm, payload and supports.
  - Calibrate the room, cart, cameras, wrist mounts and encoders.
  - Output: `RigConfig`, `Calibration`, `Scene`, and uncertainty/error reports.
- **Step 2 — interpret the brief**
  - Director generates typed actor beats and shot goals: composition, viewing angle, cart travel, light placement, duration and tolerance.
  - Preconditions and measurable completion events accompany each beat.
  - Output: `ShotSpec`; no motor angles are requested from the LLM.
- **Step 3 — compile physical choreography**
  - Generate feasible base line/arc candidates for the selected drive type.
  - Solve both arms along each candidate; include the base pose in every camera/light transform.
  - Evaluate limits, collisions, torque/stability screening and timing; revise when needed.
  - Output: accepted `CompiledShot` and a rejection report for failed alternatives.
- **Step 4 — rehearse and generate the visual target**
  - Preview uses `CompiledShot`, with planned actor blocking and approximate set geometry.
  - Send the **camera-view render**, appearance references and timing instructions to Seedance.
  - Ask it to preserve the reference's camera motion, shot-size changes and blocking.
  - ByteDance documents clay-render references supporting spatial structure, poses, motion paths and camera angles. That enables a useful visual reference, not strict enforcement of robot constraints. [Seedance 2.5 announcement](https://seed.bytedance.com/en/blog/one-take-creation-flexible-referencing-introducing-seedance-2-5)
  - Keep the executable trajectory unchanged if the generated preview drifts. A requested motion change returns to compilation.
- **Step 5 — run the real take**
  - User starts an accepted plan; recording is acknowledged before shot progress starts.
  - Local cameras and encoders update `WorldState` continuously.
  - Shared progress advances according to the shot; cart tracking and the two-arm QP execute together.
  - Bounded image correction absorbs small actor deviations; large deviations trigger a stop/revision.
- **Step 6 — actor guidance**
  - `at_mark`, `entered`, `paused`, `turned`, and intentional `exit` are confidence-gated observed events.
  - Pre-generated/cached voice cues avoid cloud latency during action.
  - Uncertain observations cannot complete a beat or accuse the actor of a mistake.
- **Step 7 — evaluate and finish**
  - Compare actual framing, beat timing, smoothness and recording completeness against the accepted specification.
  - Keep attribution as actor/camera/lighting/uncertain with evidence.
  - Reshoot the affected shot if needed; FFmpeg assembles the selected real takes.
  - Seedance finishing is a separate generated derivative; preserve original clips and record provenance.

For review metrics, define feature error $e_{\xi}=\xi-\xi^*$, then:

$$
\operatorname{RMSE}_{\rm framing}=\sqrt{\frac1N\sum_k\|e_{\xi,k}\|^2},\quad
\operatorname{usable\ fraction}=\frac{\#\{k:\|e_{\xi,k}\|\le\epsilon_{\xi}\}}{N_{\rm required}}.
\tag{47}
$$

Specify the coordinate normalization and exclude intentional exits from the required tracking window. Do not manufacture a universal “cinematic quality score.”

## 11. Implementation tree, process boundaries and interfaces

- **`take-one/`**
  - **`backend/takeone/`**
    - `contracts.py` — Pydantic schemas for rig, scene, measurements, ShotSpec, CompiledShot and take findings.
    - `director.py` — one LLM tool loop; inspect, draft, compile, revise, preview and review.
    - `coordinator.py` — explicit setup/rehearsal/record/review state machine.
    - `api.py` — FastAPI endpoints and UI WebSocket.
    - **`motion/`**
      - `model.py` — pinned MuJoCo model, five-joint attachments, frame transforms and Jacobians.
      - `vehicle.py` — one selected drive model and curvature-aware path tracker.
      - `compile.py` — candidate base routes, two-arm IK, retiming and feasibility reports.
      - `phase.py` — shared progress and local Ruckig speed/stop generation.
      - `control.py` — prescribed-base compensation and the ten-arm-joint QP.
      - `guards.py` — state freshness, non-linear clearance, limits, stopping and payload capability status.
    - **`perception/`**
      - `overview.py` — OpenCV markers, cart board and MediaPipe actor observations.
      - `geometry.py` — ray/plane geometry and valid two-view triangulation.
      - `estimate.py` — filtering, timestamps, covariance, identity and prediction validity.
      - `beats.py` — confidence-gated actor events, cue requests and intentional tracking release.
    - **`drivers/`**
      - `so101_five_joint.py` — only the five calibrated surviving motors; convert physical units at this boundary.
      - `cart.py` — the verified ESC/steering or independent-wheel interface, with no auto-detected guess.
    - **`media/`**
      - `seedance.py` — asynchronous reference-generation job and provenance.
      - `review.py` — metrics and evidence-linked findings.
      - `export.py` — FFmpeg assembly and preserved originals.
  - **`web/`**
    - React/TypeScript/Three.js: brief, shot review, scene marks, rehearsal, live state and take review.
    - Import generated scene transforms and joint metadata; do not implement another independent IK solver.
  - **`ios/`**
    - Swift/AVFoundation: one tested capture pipeline, recording and camera settings.
    - Apple Vision: observations from the capture stream with the same frame timestamps.
    - Network client: compact observations, command acknowledgements and completed media transfer.
  - **`assets/`**
    - Pinned SO-101 source model and its license.
    - Generated five-joint camera/light variants, measured payload shapes and scene collision geometry.
  - **`config/`**
    - Device identity, steering type, calibration, capabilities and runtime settings.
    - Hardware-specific numbers live here or in calibrated model assets, not in LLM prompts as guessed constants.
  - **`tests/`**
    - Mathematical model checks, simulation scenarios, observation replays and hardware acceptance scripts.
  - **`data/`**
    - SQLite metadata, immutable plans, telemetry, original clips and generated derivatives.

### Process and transport tree

```mermaid
flowchart TD
    A["Local coordinator"] --> B["Director and media jobs"]
    A --> C["Browser UI"]
    A --> D["Control process"]
    E["Overview process"] --> D
    F["iPhone observations"] --> D
    D --> G["Five-motor camera bus"]
    D --> H["Five-motor light bus"]
    D --> I["Verified vehicle adapter"]
```

- Keep the motor loop isolated from cloud calls, media encoding and browser rendering.
- Use reliable local IPC for plan/start/stop commands; latest-value slots for observations and state. On one computer, standard multiprocessing queues/pipes/shared snapshots suffice; a broker is unnecessary.
- Phone observations may use an ordered local connection, but the receiver always enforces age and sequence numbers. Reconnection cannot replay stale motor goals.
- Model a `JointState` as `{joint_names[5], position_rad[5], time, status}` per arm. There is no sixth element.
- `WorldState` distinguishes planned, measured and predicted values, with source, timestamp and uncertainty.
- A command batch carries `{plan_id, revision, sequence, local_time, phase, five_joint_targets_A, five_joint_targets_B, vehicle_command}`.
- Initial engineering targets: arm loop around `30–50 Hz`, phone/overview observations around `15–30 Hz`, UI around `15–30` state updates per second. These are budgets until measured on your equipment.
- Measure observation age, compute time, bus time, command-to-motion delay and settling separately. A fast QP or smooth browser display does not establish total robot response time.
- Pin the tested dependencies in a lockfile. The environment versions used for this report appear in §12; they are not a promise that every package combination is already validated on the team's Windows/Mac machines.

## 12. Executed simulation evidence and its limits

### 12.1 Reproducibility and model provenance

- Source repository: `TheRobotStudio/SO-ARM100`.
- Pinned revision: `eecbe3e0a9ebb23e25ad7b2759b03884c6660903`.
- Sources: `Simulation/SO101/so101_new_calib.urdf`, `so101_new_calib.xml`, corresponding mesh assets and repository license.
- Adapter: `takeone_validation/build_model.py`.
- Simulation/test harness: `takeone_validation/simulate.py`.
- Numerical results: `takeone_validation/results/simulation_results.json`.
- Full execution log: `takeone_validation/results/run.log`.
- File hashes: `takeone_validation/results/sha256.json`.
- Random seed for geometry/perception fixtures: `20260911`; control observation-noise seeds: `1, 2, 3`.

The test model has **13 generalized coordinates**: three planar base coordinates plus two sets of five arm joints. It has **10 arm actuators**, with no gripper actuator. Wheel meshes are illustrative; steering is evaluated in the numerical vehicle model. Wheel spin, tire contact forces and suspension are not simulated by those meshes.

| Executed dependency | Version |
|---|---|
| mujoco | 3.13.0 |
| osqp | 1.1.3 |
| cv2 | 5.0.0 |
| ruckig | 0.19.4 |
| numpy | 2.3.5 |
| scipy | 1.17.0 |

### 12.2 Assumptions used in the numerical experiments

| Quantity | Simulation assumption | Physical status |
|---|---:|---|
| Cart body mass | 4.0 kg, plus wheel geometry masses | Unmeasured |
| Cart deck height | 0.22 m | Unmeasured |
| Wheelbase | 0.32 m | Unmeasured |
| Driven-wheel track | 0.34 m | Unmeasured |
| Wheel radius | 0.055 m | Unmeasured |
| Supporting contacts | Four contacts around a rectangle | Total real wheel/support count unknown |
| Camera payload including holder | 0.30 kg | Unmeasured |
| Light payload including holder | 0.12 kg | Unmeasured |
| Optical offset in wrist-roll frame | `(0.025, 0.050, -0.060)` m | Holder geometry unmeasured |
| Optical orientation | 180° about local x | Holder orientation unmeasured |
| Assumed continuous torque cap | 1.0 N·m | Not a manufacturer rating |
| Simulated servo response | 80 N·m/rad proportional gain, 2.5 N·m·s/rad damping | Not measured servo behaviour |
| Closed-loop plant | 80 ms first-order response and 8% vehicle travel error | Synthetic disturbance model |
| Vision delay/noise in control test | 60 ms; 0.0008 focal-normalized standard deviation | Synthetic observations |

The published joint transforms and limits are real source data. The rest of this table is deliberately visible so that numerical output cannot be confused with measurements of your rig.

### 12.3 Results

The harness continues analyzing candidate trajectories after a failed gate to expose their limitations. A production controller would not mark the same trajectory ready for physical execution while its payload gate is failed. “Revised trajectory” in the control comparison means the kinematically revised numerical fixture.

**25 scenario checks passed; 1 payload-capacity check failed.** Passing a numerical scenario is not hardware approval.

| Executed check | Result | Measured outcome / interpretation |
|---|---|---|
| `five_joint_topology` | PASS | 10 arm actuators; 13 generalized coordinates |
| `independent_urdf_fk` | PASS | 100 poses: max 2.951 µm translation and 1.34e-05 rad rotation difference between source representations |
| `analytic_jacobians` | PASS | 100 poses: position 1.67e-10, orientation 5.67e-10, image 5.26e-10 maximum absolute finite-difference error |
| `unreachable_goal_rejection` | PASS | 2 m rise rejected; residual 1.780 m |
| `both_2wd_models` | PASS | Analytic-arc endpoint difference 7.13e-10 m; assumed Ackermann minimum radius 0.554 m |
| `nonholonomic_rejections` | PASS | Sideways velocity rejected; zero-speed Ackermann spin excluded; differential spin possible in its model |
| `synthetic_camera_geometry` | PASS | Marker ID 7 detected; 100 noisy PnP trials, position p95 3.88 mm |
| `monocular_depth_ambiguity` | PASS | Distinct points at 1 m and 2 m depth have the same pixel projection |
| `synthetic_two_view_triangulation` | PASS | 300 points; 0.6 m baseline and 1 px noise; position p95 22.42 mm, ideal known extrinsics |
| `synthetic_localization_ekf` | PASS | XY RMSE 3.61 mm vs biased odometry 58.02 mm |
| `plan_compiler` | PASS | 1201 samples; max aim error 0.0664°; joint speed 0.0866 rad/s, acceleration 0.0957 rad/s², piecewise jerk 1.571 rad/s³ |
| `request_revision_required` | PASS | Original exact-position request rejected: required change 0.199 m exceeds 0.020 m tolerance |
| `coupled_motion_feedback` | PASS | 12-second arc, 600 ticks/run, 3 feedback-noise seeds; coordinated/replay framing RMSE ratio 0.0318 |
| `cross_arm_swept_samples` | PASS | 121 samples; minimum modeled cross-arm distance 0.135 m |
| `obstacle_rejection` | PASS | Deliberate intersection detected; signed distance -0.087 m |
| `mujoco_arm_dynamics` | PASS | 1500 steps over 3 s; max joint error 0.0279 rad; force cap reached. Pass means stable integration only |
| `illustrative_payload_capacity_gate` | **FAIL — retained** | Demand 1.074 N·m exceeds allowed 0.800 N·m under assumed cap/margin |
| `support_polygon_screen` | PASS | Nominal quasi-static margin 0.122 m; intentionally unstable case -0.151 m |
| `shared_phase_local_ruckig` | PASS | Local progress trajectory 8.57 s; bounds respected |
| `runtime_fault_contracts` | PASS | 6 decision cases; no physical watchdog/stop claim |
| `jerk_limited_stopping` | PASS | Jerk-limited stop including delay 0.078 m vs acceleration-only lower bound 0.054 m |
| `3d_renderer` | PASS | Actual modified-model render and dual-view 3D rehearsal clip |
| `actor_beat_fixture` | PASS | Synthetic entry, pause, loss, resume and exit; loss stays unknown rather than completing exit |
| `shared_reference_contract` | PASS | Same-phase reference difference zero; 350 ms skew causes 0.0382 rad joint-vector discrepancy |
| `seedance_reference_contract` | PASS | Reference and hash fixture produced; provider NOT called |
| `ffmpeg_simulated_take_assembly` | PASS | Real FFmpeg assembly: 96 rendered frames, 12.00 seconds; no phone capture |

### 12.4 What the control comparison establishes

- A single 12-second accepted **revised** arc trajectory was evaluated, with both arm targets changing as the base moves.
- The actor fixture adds `35 mm` lateral and `18 mm` vertical sinusoidal deviations from the planned target.
- The camera feedback is delayed/noisy; the base plant travels 8% less than its nominal velocity command.
- Compare nominal replay, an independently delayed arm schedule, and coordinated tracking.
- The controller directly receives simulated base/joint state. The EKF and image-feature simulations are separate tests; a complete noisy localization-to-controller pipeline was **not** executed.
- The Ackermann and differential controllers use the same feasible arc/twist in this comparison, so their traces nearly coincide. This is not proof that they have equal steering, maneuverability or hardware behaviour.
- The nominal-replay baseline does not use image noise, so its repeated seed results are identical. The three seeds vary feedback measurement noise, not three independently sampled physical robots.
- An independently delayed arm schedule happens to reduce some error in this particular fixture. Do not claim that every delayed schedule is worse than replay; the useful comparison is that observed feedback corrects the injected departures in this scenario.
- The speed/profile governor and image controller operate on a local numerical model. Hardware latency, backlash, occlusion, RF interference and rolling shutter remain separate validation work.

| Scenario | Mean framing RMSE, focal-normalized | Mean base endpoint error (m) | Highest per-run p95 QP setup + solve (ms) |
|---|---:|---:|---:|
| open loop ackermann | 0.033869 | 0.038591 | not used |
| independent clocks ackermann | 0.027477 | 0.038591 | not used |
| coordinated ackermann | 0.001077 | 0.001270 | 1.158 |
| coordinated differential | 0.001077 | 0.001270 | 1.217 |

The numerical improvement is specific to this synthetic fixture. QP timing excludes perception, bus communication and motor response; it is not an end-to-end latency measurement.

### 12.5 Two retained findings that change the build decision

- **The requested camera-position/aim combination needed revision.**
  - The initial soft IK solve shifted one requested end-effector position by approximately `0.199 m` to satisfy its other objectives.
  - With a `0.020 m` position tolerance, the original exact request must be rejected.
  - The subsequent simulation explicitly uses the revised achievable trajectory fixture. This is not a claim that the original request was physically achieved.
- **The illustrative payload fails the chosen torque margin.**
  - Maximum inverse-dynamics demand is approximately `1.074 N·m` under the assumed model.
  - A `1.0 N·m` continuous cap with a 20% margin permits `0.8 N·m`.
  - The separate dynamic rollout remains numerically stable but reaches its actuator-force cap. Integration stability is not a payload-capacity pass.
  - Resolve by measuring the actual motor/voltage/continuous capability and payload, reducing lever arm or extension, revising the shot/setup, or adding suitable mechanical support.
  - Do not change the cap in software merely to make the test green.

### 12.6 Every workflow stage is accounted for

| Stage | What was executed | What remains untested |
|---|---|---|
| Hardware/model setup | Pinned model adaptation; five-joint topology checks; independent FK and Jacobian comparisons | Real assembly, encoder zero/sign, mount and payload measurement |
| Script interpretation | Deterministic shot/actor fixtures, with explicit goals and revision result | Actual LLM provider interpretation and tool-call reliability |
| World measurement | OpenCV detection of a synthetic marker; noisy PnP; two-view triangulation; localization EKF | Real room calibration, real face/body detectors, identity and actual timestamp alignment |
| Vehicle motion | Both drive equations integrated and compared with analytic arcs; impossible lateral/spin cases checked | Actual steering/ESC/wheel feedback, tire slip and drivetrain dynamics |
| Coupled arm/cart planning | Two actual five-joint chains along a moving base trajectory, residual and motion-limit checks | General route search, real geometric errors and live replanning |
| Coordinated execution | Local QP, delayed synthetic image feedback, actuator-lag model and moving actor point | Full sensor-to-hardware integration, arbitrary steering transitions and real bus timing |
| Physics/load | MuJoCo fixed-base arm dynamics; separate moving-base prescribed-trajectory inverse-dynamics demand; quasi-static support screen | Wheel-ground physics, suspension, dynamic ZMP and measured torque/thermal limits |
| Clearance | Sampled cross-arm mesh distances; a deliberately intersecting obstacle rejected | All-pair continuous checking, cables, human protection and collision constraints inside a complete runtime controller |
| Synchronization | Local Ruckig phase/stop generation and shared-reference comparison | A single integrated adaptive-phase/closed-loop run under real clock and transport faults |
| Actor rehearsal | Synthetic entry/pause/loss/resume/exit state machine | Real action recognition and live spoken cues |
| 3D preview | Actual MuJoCo render and 96-frame dual-view rehearsal video | Real-versus-preview registration and visual recording fidelity |
| Seedance | Reference clip and provenance/job fixture generated; plan hash preserved | Provider submission, motion fidelity, latency and account access |
| Recording/export | Actual FFmpeg split/reassembly of simulated-camera footage | AVFoundation capture, local audio, phone thermals, record acknowledgement and media transfer |
| Failures | Guard decisions for stale observations, identity loss, obstacle, stale calibration and solver failure | Physical stopping, watchdogs and hardware emergency stop |

The archive contains `rig_simulation.png`, `coordination.png`, `rehearsal.mp4`, and `assembled_simulated_take.mp4`. These are simulation evidence. The rehearsal video is not a Seedance-generated clip or real robot footage.

## 13. Physical acceptance gates before any claim of accurate live filming

```mermaid
flowchart TD
    A["Five-joint rig and drive identity"] --> B{"Calibration and payload pass?"}
    B -->|"No"| C["Measure or revise hardware/setup"]
    B -->|"Yes"| D["Low-speed arm and cart checks"]
    D --> E{"Coupled tracking and stopping pass?"}
    E -->|"No"| F["Revise limits, timing or path"]
    E -->|"Yes"| G["Live rehearsal and recorded take"]
    G --> H["Compare measured result with specification"]
```

- **G0 — identify the real rig**
  - Confirm which two wheels are driven and how the cart steers; record the physical supports.
  - Confirm five surviving joints per arm and whether both units are suitable powered followers.
  - Weigh phone, holder, light and mounts; measure COM offsets and attachment orientation.
  - Confirm the servo voltage/model and admissible continuous loading; check supply current margin.
- **G1 — establish geometry**
  - Verify encoder zero/sign in each axis with small single-joint movements.
  - Calibrate camera intrinsics in the actual recording mode and the wrist-to-camera transform.
  - Register cart, arms and marker boards to the same world frame.
  - Compare FK camera poses against externally observed held-out poses across the working range.
  - Store physical tolerances from those measurements. Do not inherit the simulation's tiny numerical residuals.
- **G2 — validate loads and movement**
  - Hold the worst planned poses under payload; log droop, temperature, oscillation and available current/error flags.
  - Measure start delay, steady tracking error, stopping distance, backlash and recovery under several small moves.
  - Drive straight and curved cart paths on the intended floor with payload attached.
  - Test whether arm motion shifts or rocks the cart, and whether acceleration affects footage.
- **G3 — close the perception loop**
  - Validate real face/body correspondence and triangulation against measured locations.
  - Exercise moving actor, pause, turn, intentional exit, occlusion and a second person crossing.
  - Measure actual time skew and end-to-end image-to-motion latency.
  - Confirm that low confidence inhibits metric movement and that generated/reference states never masquerade as observations.
- **G4 — coordinated rehearsal**
  - Begin at slow speed; both arms and cart use one accepted plan.
  - Introduce a small cart tracking error and actor deviation; verify bounded correction.
  - Exercise stops with sensor loss and a blocked route; check that the camera arm does not continue alone.
  - Validate the entire approach, take, pause/resume, stop and recovery sequence.
- **G5 — real capture**
  - Verify recording acknowledgement, actual lens/crop, audio, thermal stability and media integrity.
  - Compare planned and observed framing/timing, then export the real footage.
  - Enable the Seedance preview/finishing claim only after a successful provider run with the actual access path.

## 14. Build order and consequential decisions

- **First: exact model and hardware truth**
  - Retain the first five joints, remove the sixth, and replace the payload model.
  - Determine steering and supports before binding the cart driver.
  - Resolve the payload/torque gate before automatic motion near an actor.
- **Second: one physical pose, then one short coupled path**
  - Reach a calibrated camera pose with a stationary cart.
  - Execute a short cart line with arm compensation and the second arm represented in collision/stability checks.
  - Add a smooth arc only after the cart's steering and localization are measured.
- **Third: live adaptation and choreography**
  - Enable bounded image corrections and actor beat events.
  - Activate shared progress slowdown/stopping on observed lag or uncertainty.
  - Add moving-light choreography after combined load/clearance validation.
- **Fourth: the creative presentation layer**
  - Reuse the same trajectory for rehearsal and the Seedance motion reference.
  - Complete record, review, reshoot and conventional export.
- **Items deliberately absent from the initial architecture**
  - A trained physics/VLA model, ROS navigation stack, general obstacle-detour planning, dense scene reconstruction, a second IK implementation in JavaScript, direct LLM motor control, and Seedance-to-motor trajectory reconstruction.
- **Final engineering commitment**
  - The selected approach is **model-based planning plus measured feedback and coordinated execution**.
  - The actual SO-101 kinematic chain is represented and tested; physical accuracy is obtained through calibration and feedback.
  - A physically unsupported request is revised. A failed load or stopping check remains failed until evidence or a real design change resolves it.

## 15. Source and evidence tree

- **Robot geometry and modification**
  - [RobotStudio repository at the pinned revision](https://github.com/TheRobotStudio/SO-ARM100/tree/eecbe3e0a9ebb23e25ad7b2759b03884c6660903)
  - [SO-101 new-calibration URDF](https://github.com/TheRobotStudio/SO-ARM100/blob/eecbe3e0a9ebb23e25ad7b2759b03884c6660903/Simulation/SO101/so101_new_calib.urdf)
  - [SO-101 new-calibration MuJoCo XML](https://github.com/TheRobotStudio/SO-ARM100/blob/eecbe3e0a9ebb23e25ad7b2759b03884c6660903/Simulation/SO101/so101_new_calib.xml)
  - [Hugging Face SO-101 setup](https://huggingface.co/docs/lerobot/en/so101)
- **Mathematics and solvers**
  - [Modern Robotics: mobile manipulation](https://modernrobotics.northwestern.edu/nu-gm-book-resource/13-5-mobile-manipulation/)
  - [MuJoCo dynamics](https://mujoco.readthedocs.io/en/stable/computation/index.html)
  - [MuJoCo API and site Jacobians](https://mujoco.readthedocs.io/en/stable/APIreference/APIfunctions.html)
  - [OSQP problem formulation](https://osqp.org/docs/)
  - [Mink task-based IK](https://kevinzakka.github.io/mink/)
  - [Ruckig local motion generation and waypoint limitations](https://github.com/pantor/ruckig)
  - [CasADi numerical optimization](https://web.casadi.org/docs/)
- **Perception**
  - [OpenCV camera model and reconstruction](https://docs.opencv.org/4.x/d9/d0c/group__calib3d.html)
  - [OpenCV PnP](https://docs.opencv.org/4.x/d5/d1f/calib3d_solvePnP.html)
  - [Apple face landmark detection](https://developer.apple.com/documentation/vision/vndetectfacelandmarksrequest)
  - [MediaPipe Pose Landmarker](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker/python)
- **Compared architectures and generative reference**
  - [Nav2 Smac planners](https://github.com/ros-navigation/navigation2/tree/main/nav2_smac_planner)
  - [XLeRobot](https://github.com/Vector-Wangel/XLeRobot)
  - [Seedance 2.5 clay-render and motion references](https://seed.bytedance.com/en/blog/one-take-creation-flexible-referencing-introducing-seedance-2-5)
- **Local evidence in the companion archive**
  - Source files, pin/provenance, modified model, measured numerical results, plots, render video, export video, execution log and SHA-256 manifest.
  - Previously supplied project documents informed requirements; numerical robot constants were replaced with the pinned published model.

All external sources were inspected during this session. Where capability pages were inaccessible, no unsupported API signature or hardware rating was substituted. The decision is grounded in the linked primary sources and the explicitly scoped experiments, rather than in claims of universal physical understanding.
