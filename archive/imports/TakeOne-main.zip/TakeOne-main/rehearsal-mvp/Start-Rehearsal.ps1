param([int]$Port = 8766)
$ErrorActionPreference = 'Stop'
$projectPath = $PSScriptRoot
$pythonPath = Join-Path (Split-Path $projectPath -Parent) 'TAKE-ONE-Simulation-Evidence\takeone_validation\.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) { throw 'The simulation Python environment is missing. See README.md for setup.' }
if (-not (Test-Path -LiteralPath (Join-Path $projectPath 'node_modules\three'))) {
    Push-Location $projectPath
    try { npm ci --no-audit --no-fund; if ($LASTEXITCODE -ne 0) { throw 'Unable to install Three.js' } }
    finally { Pop-Location }
}
try {
    $health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/health" -TimeoutSec 2
    if ($health.mode -eq 'local rehearsal') { Write-Host "Already running: http://127.0.0.1:$Port"; exit 0 }
} catch { }
Write-Host "Open http://127.0.0.1:$Port once the ready message appears. Ctrl+C stops the server."
& $pythonPath (Join-Path $projectPath 'build_rehearsal_model.py')
if ($LASTEXITCODE -ne 0) { throw 'Unable to generate the height-correct model.' }
& $pythonPath (Join-Path $projectPath 'server.py') --port $Port
