"""Loopback-only static UI and bounded shot compiler API. No motor or cloud endpoints."""
import json
import argparse
import mimetypes
import threading
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, unquote
from engine import ROOT, compile_shot, visual_model

MODEL_DATA=None
DEFAULT_SHOT=None
COMPILE_LOCK=threading.Lock()

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(ROOT/'dist'),**kwargs)
    def translate_path(self,path):
        requested=unquote(urlparse(path).path)
        if requested.startswith('/vendor/'):
            base=(ROOT/'node_modules'/'three').resolve()
            candidate=(base/requested.removeprefix('/vendor/')).resolve()
            if candidate.is_relative_to(base): return str(candidate)
            return str(ROOT/'dist'/'missing')
        return super().translate_path(path)
    def json_response(self,data,status=200):
        blob=json.dumps(data,allow_nan=False,separators=(',',':')).encode()
        self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(blob)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(blob)
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/api/model': return self.json_response(MODEL_DATA)
        if path=='/api/shot': return self.json_response(DEFAULT_SHOT)
        if path=='/api/health': return self.json_response({'ok':True,'mode':'local rehearsal'})
        return super().do_GET()
    def do_POST(self):
        if self.path!='/api/compile': return self.json_response({'error':'Not found'},404)
        origin=self.headers.get('Origin')
        port=self.server.server_port
        if origin and origin not in (f'http://127.0.0.1:{port}',f'http://localhost:{port}'):
            return self.json_response({'error':'Local origin required'},403)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size<1 or size>4096: raise ValueError('Invalid settings size')
            settings=json.loads(self.rfile.read(size))
            if not COMPILE_LOCK.acquire(blocking=False): return self.json_response({'error':'A shot is already compiling. Try again shortly.'},409)
            try: shot=compile_shot(settings)
            finally: COMPILE_LOCK.release()
            return self.json_response(shot)
        except (ValueError,TypeError) as e: return self.json_response({'error':str(e)},400)
        except Exception as e:
            print('Compile failed:',repr(e),flush=True)
            return self.json_response({'error':'Shot compilation failed. Previous plan preserved.'},500)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    mimetypes.add_type('text/javascript','.js')
    print('Loading MuJoCo robot and compiling rehearsal…',flush=True)
    MODEL_DATA=visual_model();DEFAULT_SHOT=compile_shot()
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
    print(f'TAKE ONE ready at http://127.0.0.1:{args.port}',flush=True)
    server.serve_forever()
