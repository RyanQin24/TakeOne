# TAKE ONE rehearsal MVP

Local interactive rehearsal for the supplied video's “actor turns / camera orbits” pairing.

**Resize update (2026-09-11):** Cart deck and both arm mounts now sit at **1.20 m**. An explicit raised pose reaches **1.701 m at the camera point**, with the original SO-101 link transforms, meshes, joints and inertias unchanged. Default filming height is **1.50 m**. The requested 55–60 cm reach remains approximate: this chain has a 53.5 cm loose radial upper bound and approximately 50.1 cm demonstrated vertical rise. No 60 cm reach is claimed.

`build_rehearsal_model.py` produces `rig_tall.xml` from the untouched original evidence model. Cart footprint and wheel geometry remain placeholders; a support column and upper deck represent the height, not a measured mechanical design. The original assumed 4 kg chassis mass is redistributed as 3 kg low chassis, 0.5 kg column and 0.5 kg upper deck; this is not a mass measurement. The new default shot exceeds the assumed torque margin (0.848 vs 0.800 N·m), which is prominently warned in the interface. Hardware approval remains false.

**Audit status:** The [math, physics and logic audit](MATH-PHYSICS-AUDIT.md) records the pre-resize numerical snapshot and unresolved vehicle-reference, braking and collision-world issues. Resizing does not resolve those issues. Passing tests or nominal screens is not physical validation.

Run `./Start-Rehearsal.ps1` in PowerShell, then open http://127.0.0.1:8766. The resized preview uses port 8766 because the old server on 8765 could not be automatically restarted. The server binds only to loopback and has no hardware or cloud control endpoint. It uses the Python 3.12 virtual environment created for the neighboring validation bundle and a pinned local Three.js installation (`npm ci`). The original evidence bundle and original Markdown are not changed.

## Try it

1. Press **Rehearse**. Orbit or zoom the world view; use **Robot** to inspect the actual arm meshes.
2. Choose **Try a half-speed turn**. **Follow actor** slows the robot timeline to the synthetic actor observation. **Fixed clock** continues on its own schedule; compare the beat mismatch and frame error.
3. Try **Pause actor**, **Test tracking loss**, or **Block robot path**. Fault controls simulate a supervisory HOLD, not physical stopping dynamics.
4. Change the shot radius, arc, duration, actor turn/height, or camera height, then **Recalculate shot**. Motion/clearance failures inhibit playback. An infeasible camera height needs explicit acceptance of the achieved height for rehearsal.
5. Adjust camera FOV, light angle and intensity. Camera/light volumes are visible in the world view only. The monitor is rendered from the solved camera pose. Spoken actor cues are opt-in and depend on browser speech support.
6. **Export shot** downloads JSON containing the model hash, settings, actor cues, nominal joint poses and optical poses. It is a rehearsal artifact, not a hardware command file.

## What actually runs

`engine.py` loads the supplied MuJoCo model, including both five-joint SO-101 chains and their attached tools. It solves an actor-centered, tangent-heading cart arc and both optical targets using SciPy bounded least squares. The camera aim includes an upright image-axis constraint. A clamped cubic spline generates 321 nominal samples. Screens cover joint ranges, derivatives, arc steering/speed, sampled cross-arm geometry distances, requested camera height, and inverse-dynamics arm demand using the existing assumed 1 N·m cap / 20% margin.

The browser receives MuJoCo's compiled mesh vertices/offsets and per-sample body/optical poses. It interpolates these poses for display; no alternate JavaScript IK model is used. Three.js renders the set, a dimensioned mannequin, live camera view and approximate spotlight/shadows. The mannequin is not a reconstruction of the person in the video.

`rehearsal.js` controls two phase tracks. The synthetic actor phase is the observation input; follow mode adjusts the robot's shared phase, while fixed-clock mode does not. The scene, two arms and camera monitor all read the same robot phase. The simulated image error is the distance of the actor's target point from the image center, normalized by image width and height. Beat mismatch is the difference in intended actor-turn angle between the two phase tracks. This MVP does not estimate actor pose from the camera image or run the archive's OSQP feedback loop.

## Boundaries

- Reference interpretation is authored for one shot; no automatic video-to-trajectory inference or external model call.
- Cart, tool mounts, payload, actuator properties and scene dimensions retain assumptions pending measurements/photos. Lens field of view is adjustable, not calibrated.
- The cart is kinematic. Tire contact, suspension, dynamic stopping and hardware transport are absent. Adaptive phase transitions have not undergone full torque/jerk validation.
- Nominal collision checks are sampled cross-arm checks, not continuous all-pair scene collision guarantees. The obstacle toggle is a synthetic “route blocked” fault.
- Lighting is a rendered spotlight, not photometric calibration or measured illumination.
- The original archive's failed payload gate applies to its original shot. This new orbit has its own computed demand; a passing assumed screen does not overturn the original result or approve hardware.
- Hardware approval is always false. There is no motor driver, physical actor detection, recording integration, or Seedance submission.
- HTML slider edits invalidate the plan. FOV/light adjustments only change the view, not physical lens settings. Accepting a revised height explicitly keeps the solved trajectory for rehearsal.

## Verification

`npm test` checks the shared progress behavior, slower actor, independent clocks, pause/resume, completion, and fault holds. Run `../TAKE-ONE-Simulation-Evidence/takeone_validation/.venv/Scripts/python.exe -m unittest test_engine.py` to check pose agreement with MuJoCo, upright framing, steering geometry, rejected requests, compiled mesh export, and invalid inputs.

The UI offers optional WebMCP `read_rehearsal` and `configure_rehearsal_playback` tools. Both use the same page state as the visible controls; neither runs motors or sends data externally.

Robot geometry derives from TheRobotStudio/SO-ARM100, revision `eecbe3e0a9ebb23e25ad7b2759b03884c6660903`, under Apache-2.0. Original source, provenance and license remain in `../TAKE-ONE-Simulation-Evidence/takeone_validation/upstream/`. Three.js is MIT licensed; its license is in `node_modules/three/LICENSE`. The reference clip was provided by the user and is served only locally.
