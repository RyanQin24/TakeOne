"""Generate the height-correct rehearsal variant without editing the source evidence.

Only the 1.20 m cart/mount height is user-confirmed. Footprint, support design,
mass distribution and drive geometry remain illustrative, not measured hardware.
Arm transforms, meshes, payloads, joints and link inertias are NOT scaled.
"""
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'TAKE-ONE-Simulation-Evidence/takeone_validation/rig_5dof.xml'
DESTINATION = ROOT / 'rig_tall.xml'
MOUNT_HEIGHT = 1.2


def build():
    tree = ET.parse(SOURCE)
    root = tree.getroot()
    root.set('model', 'TAKE_ONE_120cm_mount_rehearsal_unmeasured_dynamics')
    root.find('compiler').set('meshdir', '../TAKE-ONE-Simulation-Evidence/takeone_validation/upstream/assets')
    cart = root.find(".//body[@name='cart']")
    # Preserve the low wheel/chassis geometry and redistribute the existing assumed
    # 4 kg cart mass explicitly. This is a visual support placeholder, not a design.
    cart.find("geom[@name='cart_box']").set('mass', '3')
    ET.SubElement(cart, 'geom', name='cart_support', type='box',
                  pos='0 0 0.68', size='.055 .055 .48', mass='.5', rgba='.25 .31 .35 1')
    ET.SubElement(cart, 'geom', name='cart_deck', type='box',
                  pos='0 0 1.18', size='.23 .19 .02', mass='.5', rgba='.22 .27 .33 1')
    for name in ['cam_base', 'light_base']:
        mount = cart.find(f"body[@name='{name}']")
        xyz = mount.get('pos').split()
        mount.set('pos', f'{xyz[0]} {xyz[1]} {MOUNT_HEIGHT}')
    ET.indent(tree)
    tree.write(DESTINATION, encoding='unicode')
    return DESTINATION


if __name__ == '__main__':
    print(build())
