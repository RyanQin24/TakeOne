"""Local rehearsal compiler. Uses the supplied MuJoCo model; never sends motors commands."""
from pathlib import Path
import hashlib
import json
import math
import time
import numpy as np
import mujoco
from scipy.optimize import least_squares
from scipy.interpolate import CubicSpline
from scipy.spatial.transform import Rotation

ROOT = Path(__file__).resolve().parent
BUNDLE = ROOT.parent / 'TAKE-ONE-Simulation-Evidence' / 'takeone_validation'
MODEL = ROOT / 'rig_tall.xml'
DEFAULTS = dict(radius=1.6, orbit=35., duration=16., actorHeight=1.72, turn=70., cameraHeight=1.5)

def parameters(raw):
    if not isinstance(raw, dict):
        raise ValueError('Shot settings must be an object')
    limits = dict(radius=(.8,2.5), orbit=(10,70), duration=(8,30), actorHeight=(1.3,1.95), turn=(20,120), cameraHeight=(.6,1.8))
    if set(raw) - set(DEFAULTS):
        raise ValueError('Unknown shot setting')
    result = DEFAULTS.copy()
    for key, value in raw.items():
        if isinstance(value, bool) or not isinstance(value, (int,float)) or not math.isfinite(value):
            raise ValueError(f'{key} must be a finite number')
        lo, hi = limits[key]
        if not lo <= value <= hi:
            raise ValueError(f'{key} must be between {lo} and {hi}')
        result[key] = float(value)
    return result

def ease(u):
    return 10*u**3-15*u**4+6*u**5

def matrix_quat(mat):
    return Rotation.from_matrix(np.asarray(mat).reshape(3,3)).as_quat().tolist()

def visual_model():
    """Export MuJoCo's compiled mesh vertices and geom offsets, including mesh recentering."""
    m = mujoco.MjModel.from_xml_path(str(MODEL))
    meshes = {}
    geoms = []
    for g in range(m.ngeom):
        if m.geom_bodyid[g] == 0 or m.geom_group[g] == 3:
            continue
        mid = int(m.geom_dataid[g])
        if int(m.geom_type[g]) == int(mujoco.mjtGeom.mjGEOM_MESH) and str(mid) not in meshes:
            va, vn = m.mesh_vertadr[mid], m.mesh_vertnum[mid]
            fa, fn = m.mesh_faceadr[mid], m.mesh_facenum[mid]
            meshes[str(mid)] = {'vertices': m.mesh_vert[va:va+vn].ravel().tolist(), 'faces': m.mesh_face[fa:fa+fn].ravel().tolist()}
        material = m.geom_matid[g]
        rgba = m.mat_rgba[material] if material >= 0 else m.geom_rgba[g]
        geoms.append(dict(id=g, body=int(m.geom_bodyid[g]), name=m.geom(g).name or f'geom_{g}',
                          kind=int(m.geom_type[g]), mesh=mid, size=m.geom_size[g].tolist(),
                          pos=m.geom_pos[g].tolist(), quat=np.roll(m.geom_quat[g],-1).tolist(), color=rgba.tolist()))
    return dict(geoms=geoms, meshes=meshes, bodyNames=[m.body(i).name for i in range(m.nbody)],
                jointNames=[m.joint(i).name for i in range(3,m.njnt)], jointLimits=m.jnt_range[3:].tolist(),
                dimensions=dict(mountHeight=1.2, cartHeight=1.2, approximateOverallHeight=1.7,
                                armReachUpperBound=.5350039834991899, cameraHeightMin=.6, cameraHeightMax=1.8,
                                confirmed=['cartHeight','mountHeight'], physicsValidated=False),
                modelHash=hashlib.sha256(MODEL.read_bytes()).hexdigest(), source='SO-101 unchanged arms; 1.20 m cart/mount variant, unmeasured support and dynamics')

def compile_shot(raw=None):
    start = time.perf_counter()
    cfg = parameters({} if raw is None else raw)
    m = mujoco.MjModel.from_xml_path(str(MODEL)); d = mujoco.MjData(m)
    sites = [m.site(f'{n}_optical').id for n in ['cam','light']]
    lo, hi = m.jnt_range[3:,0]+.04, m.jnt_range[3:,1]-.04
    phases = np.linspace(0,1,81)
    qs=[]; aims=[]; deviations=[]
    seed = np.zeros(m.nq)
    actor_scale=cfg['actorHeight']/1.72
    target = np.array([0.,0.,1.6*actor_scale])
    orbit = np.deg2rad(cfg['orbit'])
    for phase in phases:
        theta = -.5*orbit + orbit*ease(phase)
        face_yaw=np.pi-orbit/2+np.deg2rad(cfg['turn'])*ease(phase)
        target[:2]=.085*actor_scale*np.array([np.cos(face_yaw),np.sin(face_yaw)])
        q = seed.copy()
        q[:3] = [-cfg['radius']*np.cos(theta),-cfg['radius']*np.sin(theta),theta-np.pi/2]
        base_r = Rotation.from_euler('z',q[2]).as_matrix()
        for arm, site in enumerate(sites):
            sl = slice(3+arm*5,8+arm*5)
            aim = target.copy(); aim[2] -= .15*arm
            desired = base_r @ np.array([.02,.01 if arm==0 else .29,cfg['cameraHeight']-.04*arm]) + np.r_[q[:2],0.]
            prev = seed[sl].copy()
            def residual(joints):
                q[sl] = joints; d.qpos[:] = q; mujoco.mj_forward(m,d)
                p=d.site_xpos[site]; r=d.site_xmat[site].reshape(3,3)
                direction=aim-p; direction/=np.linalg.norm(direction)
                right=np.cross(direction,[0.,0.,1.]);right/=np.linalg.norm(right)
                # Optical +x is image right, +y image down, +z forward. Prevent inverted images.
                return np.r_[2*(p-desired),12*(r[:,2]-direction),1.2*(r[:,0]-right),.004*(joints-prev)]
            sol = least_squares(residual,prev,bounds=(lo[arm*5:arm*5+5],hi[arm*5:arm*5+5]), max_nfev=120,ftol=1e-8,xtol=1e-8,gtol=1e-8)
            q[sl] = sol.x; d.qpos[:]=q; mujoco.mj_forward(m,d)
            p = d.site_xpos[site]; direction=aim-p; direction/=np.linalg.norm(direction)
            aims.append(float(np.degrees(np.arccos(np.clip(d.site_xmat[site].reshape(3,3)[:,2]@direction,-1,1)))))
            if arm == 0: deviations.append(float(abs(p[2]-cfg['cameraHeight'])))
        qs.append(q.copy()); seed=q.copy()
    spline = CubicSpline(phases*cfg['duration'],qs,axis=0,bc_type=((1,np.zeros(13)),(1,np.zeros(13))))
    dense_t=np.linspace(0,cfg['duration'],321)
    dense=spline(dense_t); vel=spline(dense_t,1); acc=spline(dense_t,2); jerk=spline(dense_t,3)
    frames=[]; demand=[]; clearance=[]
    cam_geoms=[i for i in range(m.ngeom) if m.body(m.geom_bodyid[i]).name.startswith('cam_') and m.geom_group[i]!=2]
    light_geoms=[i for i in range(m.ngeom) if m.body(m.geom_bodyid[i]).name.startswith('light_') and m.geom_group[i]!=2]
    for idx,q in enumerate(dense):
        d.qpos[:]=q; d.qvel[:]=0; mujoco.mj_forward(m,d)
        frames.append(dict(q=q.tolist(), bodies=np.c_[d.xpos,d.xquat[:,1:],d.xquat[:,0]].tolist(),
                           camera=dict(pos=d.site_xpos[sites[0]].tolist(),quat=matrix_quat(d.site_xmat[sites[0]])),
                           light=dict(pos=d.site_xpos[sites[1]].tolist(),quat=matrix_quat(d.site_xmat[sites[1]]))))
        if idx%8 == 0:
            clearance.append(min(mujoco.mj_geomDistance(m,d,a,b,.5,None) for a in cam_geoms for b in light_geoms))
            d.qvel[:]=vel[idx];d.qacc[:]=acc[idx];mujoco.mj_inverse(m,d)
            demand.append(float(np.max(abs(d.qfrc_inverse[3:]))))
    margin=float(np.min(np.minimum(dense[:,3:]-m.jnt_range[3:,0],m.jnt_range[3:,1]-dense[:,3:])))
    maxv=float(np.max(abs(vel[:,3:]))); maxa=float(np.max(abs(acc[:,3:]))); maxj=float(np.max(abs(jerk[:,3:])))
    speed=float(np.max(np.linalg.norm(vel[:,:2],axis=1)))
    cam_heights=[f['camera']['pos'][2] for f in frames]
    checks = [
        dict(name='Aim at actor',passed=max(aims)<1.,value=round(max(aims),3),unit='° max'),
        dict(name='Joint limits',passed=margin>.01,value=round(np.degrees(margin),2),unit='° margin'),
        dict(name='Arm speed',passed=maxv<.8,value=round(maxv,3),unit='rad/s'),
        dict(name='Arm acceleration',passed=maxa<1.8,value=round(maxa,3),unit='rad/s²'),
        dict(name='Arm jerk',passed=maxj<12,value=round(maxj,3),unit='rad/s³'),
        dict(name='Cart speed',passed=speed<=.25,value=round(speed,3),unit='m/s'),
        dict(name='Steering radius',passed=cfg['radius']>=.32/np.tan(np.deg2rad(30)),value=round(np.degrees(np.arctan(.32/cfg['radius'])),1),unit='° steering'),
        dict(name='Sampled arm clearance',passed=min(clearance)>.015,value=round(min(clearance)*100,1),unit='cm'),
        dict(name='Camera height request',passed=max(deviations)<=.02,value=round(max(deviations)*100,1),unit='cm adjustment'),
        dict(name='Assumed payload margin',passed=max(demand)<.8,value=round(max(demand),3),unit='N·m / 0.800 allowed'),
    ]
    for check in checks: check['passed'] = bool(check['passed'])
    playable=all(c['passed'] for c in checks if c['name'] not in ['Assumed payload margin','Camera height request'])
    revised=max(deviations)>.02
    return dict(schema='take-one.shot.v1',settings=cfg,frames=frames,checks=checks,
                playable=playable,requiresRevision=revised,hardwareReady=False,
                scope='Kinematic rehearsal with sampled inverse-dynamics and clearance screens. Synthetic actor observation; no hardware or wheel-ground dynamics.',
                cameraHeightRange=[min(cam_heights),max(cam_heights)], target=target.tolist(),
                compileSeconds=round(time.perf_counter()-start,2),
                planId=hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()+MODEL.read_bytes()+Path(__file__).read_bytes()).hexdigest()[:12],
                actorCues=[{'phase':0,'text':'Stand on mark A. Face the camera. Ready.'},{'phase':.03,'text':'Action. Turn slowly toward mark B.'},{'phase':.8,'text':'Finish your turn. Hold your eyeline.'},{'phase':1,'text':'Cut. Hold position.'}])

if __name__ == '__main__':
    shot=compile_shot()
    print(json.dumps({k:v for k,v in shot.items() if k!='frames'},indent=2))
