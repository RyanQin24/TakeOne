import unittest
import numpy as np
import mujoco
import hashlib
from build_rehearsal_model import SOURCE
from scipy.spatial.transform import Rotation
from engine import compile_shot, visual_model, parameters, MODEL, ease

class CompilerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.shot=compile_shot()
        cls.m=mujoco.MjModel.from_xml_path(str(MODEL));cls.d=mujoco.MjData(cls.m)

    def test_actual_model_and_camera_pose(self):
        self.assertEqual(self.m.nu,10);self.assertEqual(self.m.nq,13)
        self.assertTrue(self.shot['playable']);self.assertFalse(self.shot['hardwareReady'])
        for i in [0,40,160,250,320]:
            f=self.shot['frames'][i];self.d.qpos[:]=f['q'];mujoco.mj_forward(self.m,self.d)
            s=self.m.site('cam_optical').id
            np.testing.assert_allclose(f['camera']['pos'],self.d.site_xpos[s],atol=1e-12)
            r=Rotation.from_quat(f['camera']['quat']).as_matrix()
            np.testing.assert_allclose(r,self.d.site_xmat[s].reshape(3,3),atol=1e-12)
            # Image +y points down. A mirrored/upside-down view would fail this.
            self.assertLess(r[2,1],-.4)
            yaw=np.pi-np.deg2rad(self.shot['settings']['orbit'])/2+np.deg2rad(self.shot['settings']['turn'])*ease(i/320)
            target=np.array([.085*np.cos(yaw),.085*np.sin(yaw),self.shot['settings']['actorHeight']-.12])
            local=r.T@(target-self.d.site_xpos[s]);self.assertGreater(local[2],0)
            self.assertLess(np.linalg.norm(local[:2]/local[2]),.002)

    def test_cart_center_arc_only_not_rear_axle_validation(self):
        q=np.array([f['q'] for f in self.shot['frames']]);v=np.gradient(q[:,:2],axis=0)
        lateral=-np.sin(q[:,2])*v[:,0]+np.cos(q[:,2])*v[:,1]
        self.assertLess(np.max(abs(lateral)),1e-6)
        np.testing.assert_allclose(np.linalg.norm(q[:,:2],axis=1),1.6,atol=1e-8)

    def test_infeasible_requests_are_flagged(self):
        high=compile_shot({'cameraHeight':1.8})
        self.assertTrue(high['requiresRevision'])
        self.assertFalse(next(x for x in high['checks'] if x['name']=='Camera height request')['passed'])
        fast=compile_shot({'orbit':70,'duration':8,'radius':2.5})
        self.assertFalse(fast['playable'])
        self.assertFalse(next(x for x in fast['checks'] if x['name']=='Cart speed')['passed'])

    def test_mesh_export_uses_compiled_mujoco_coordinates(self):
        model=visual_model();self.assertEqual(len(model['jointNames']),10)
        self.assertGreater(len(model['meshes']),5)
        for geom in model['geoms']:
            g=geom['id'];np.testing.assert_allclose(geom['pos'],self.m.geom_pos[g])
            if geom['kind']==7:
                mid=geom['mesh'];addr=self.m.mesh_vertadr[mid];n=self.m.mesh_vertnum[mid]
                np.testing.assert_allclose(np.array(model['meshes'][str(mid)]['vertices']).reshape(-1,3),self.m.mesh_vert[addr:addr+n])

    def test_input_validation(self):
        for invalid in [{'radius':float('nan')},{'duration':0},{'turn':True},{'surprise':1},[]]:
            with self.assertRaises(ValueError): parameters(invalid)

    def test_confirmed_mount_height_and_original_arm_geometry(self):
        original=mujoco.MjModel.from_xml_path(str(SOURCE))
        self.assertEqual(hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'6efaab07ad2393e0725708e4da08eef98d329777540b66b06403fa4499201908')
        for prefix in ['cam','light']:
            self.assertAlmostEqual(self.m.body_pos[self.m.body(prefix+'_base').id,2],1.2)
        deck=self.m.geom('cart_deck').id
        self.assertAlmostEqual(self.m.geom_pos[deck,2]+self.m.geom_size[deck,2],1.2)
        for i in range(original.nbody):
            name=original.body(i).name
            if not name.startswith(('cam_','light_')):continue
            j=self.m.body(name).id
            np.testing.assert_allclose(self.m.body_quat[j],original.body_quat[i])
            np.testing.assert_allclose(self.m.body_inertia[j],original.body_inertia[i])
            if not name.endswith('_base'):np.testing.assert_allclose(self.m.body_pos[j],original.body_pos[i])
        np.testing.assert_allclose(self.m.jnt_range,original.jnt_range)

    def test_raised_pose_reaches_about_170cm_without_scaling(self):
        self.d.qpos[:]=0
        self.d.qpos[3:8]=[.2452579295,-.2438059663,-1.2884520013,-.4709976955,2.0832087658]
        mujoco.mj_forward(self.m,self.d)
        height=self.d.site_xpos[self.m.site('cam_optical').id,2]
        self.assertAlmostEqual(height,1.7009801522,places=6)
        self.assertLess(height,1.2+.535004)
        # Reach witness only: this posture does not certify optical aim or clearance.

    def test_default_height_and_load_warning_are_honest(self):
        self.assertAlmostEqual(self.shot['settings']['cameraHeight'],1.5)
        self.assertTrue(all(abs(z-1.5)<.001 for z in self.shot['cameraHeightRange']))
        self.assertFalse(next(c['passed'] for c in self.shot['checks'] if c['name']=='Assumed payload margin'))
        self.assertFalse(self.shot['hardwareReady'])

if __name__=='__main__':unittest.main(verbosity=2)
